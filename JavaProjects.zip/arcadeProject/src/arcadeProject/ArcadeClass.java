package arcadeProject;

public class ArcadeClass {
	public static void main (String[] args) {
	
		int couponsWon =36;
		int couponCostCandyBar = 10;
		int couponCostGumBall = 3;
		
		System.out.println("You have won " + couponsWon + " coupons");
		System.out.println("You can buy " + (couponsWon/couponCostCandyBar) + " Candy Bar(s)");
		System.out.println("You can buy " + ((couponsWon%couponCostCandyBar)/couponCostGumBall) + " Gum Ball(s)");
		
	}	
	
}

/*You can redeem 10 coupons for a candy bar or 3 coupons for a gum ball. 
 * You prefer candy bars to gum balls. Write a program that defines a 
 * variable initially assigned to the number of coupons you win. Next, the program 
 * should output how many candy bars and gum balls you can get if you spend all of your 
 * coupons on candy bars first, and any remaining coupons on gum balls.*/


