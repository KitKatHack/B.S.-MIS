package exam2_Pt1_Q1;
	import java.util.Scanner;
public class Exam2_Pt1_Q1 {
	public static void main (String[]args) {
		Scanner scanner = new Scanner(System.in);
	
		System.out.println("How many dogs do you want to adopt?");
		int howMany = scanner.nextInt();		
		

		for (int n = 1; n<=howMany; n++) {
			System.out.println("Do you want a large, medium, or small dog?");
			String size = scanner.next().toLowerCase();
			
			System.out.println("Do you want a long-haired or short-haired dog?");
			String hairType = scanner.next().toLowerCase();
		
			
		if (size.equals ("large") && hairType.equals ("long-haired")) {
				System.out.println("Recommended Breeds: German Shepard, Bernese Mountain");
			}
				else if (size.equals ("large") && hairType.equals ("short-haired")) {
					System.out.println("Recommended Breeds: Dalmatian, Great Dane");
				}
				else if (size.equals ("medium") && hairType.equals ("long-haired")) {
					System.out.println("Recommended Breeds: Collie, Golden Retriever");
				}
				else if (size.equals ("medium") && hairType.equals ("short-haired")) {
					System.out.println("Recommended Breeds: Boxer, Beagle");
				}
				else if (size.equals ("small") && hairType.equals ("long-haired")) {
					System.out.println("Recommended Breeds: Maltese, Pomeranian");
				}
				else if (size.equals ("small") && hairType.equals ("short-haired")) {
					System.out.println("Recommended Breeds: Chihuahua, Pug");
				}
		
		}
		double adoptFee;
		double additionalFee;
		double totalFee;
		
		if (howMany == 1 || howMany == 2) {
			 adoptFee = 50 * howMany;
			 additionalFee = (15 * howMany)+(8 * howMany) + (24 * howMany);
			 totalFee = adoptFee + additionalFee;
			 
			System.out.println("\nAdoption Fee: $" + adoptFee);	
			System.out.println("\nAdditional Fees Per Dog Include: \n 1 Water Bowl: $15 \n 1 Bag of Food: $8 \n 1 Bed: $24");		
			System.out.println("\nTotal Additional Fees: $" + additionalFee);		
			System.out.println("Overall Total: $" + totalFee);		
		}
		
			else if (howMany == 3 || howMany == 4) {
				 adoptFee = 35 * howMany;
				 additionalFee = (15 * howMany)+(8 * howMany) + (24 * howMany);
				 totalFee = adoptFee + additionalFee;
				 
				System.out.println("\nAdoption Fee: $" + adoptFee);	
				System.out.println("\nAdditional Fees Per Dog Include: \n 1 Water Bowl: $15 \n 1 Bag of Food: $8 \n 1 Bed: $24");		
				System.out.println("\nTotal Additional Fees: $" + additionalFee);		
				System.out.println("Overall Total: $" + totalFee);		
		}
			else if (howMany >= 5) {
			 adoptFee = 20 * howMany;
			 additionalFee = (15 * howMany)+(8 * howMany) + (24 * howMany);
			 totalFee = adoptFee + additionalFee;
			 
			System.out.println("\nAdoption Fee: $" + adoptFee);	
			System.out.println("\nAdditional Fees Per Dog Include: \n 1 Water Bowl: $15 \n 1 Bag of Food: $8 \n 1 Bed: $24");		
			System.out.println("\nTotal Additional Fees: $" + additionalFee);		
			System.out.println("Overall Total: $" + totalFee);		
			}
		
		
		
			if (howMany < 1) {
					System.out.println("You have chosen to not adopt.");
				}
			
		}}
		