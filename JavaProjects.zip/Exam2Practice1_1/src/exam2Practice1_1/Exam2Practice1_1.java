package exam2Practice1_1;
	import java.util.Scanner;
public class Exam2Practice1_1 {
	public static void main (String []args) {
		Scanner myScannerObject = new Scanner(System.in);
		
		System.out.println ("Please indicate your academic year:\n[1] Freshman \n[2] Sophmore \n[3] Junior \n[4] Senior");
		String academicYear = myScannerObject.nextLine().toLowerCase();
		
		System.out.println ("Please input GPA: ");
		double gpa = myScannerObject.nextDouble();
		
		int semestersInAcademicYear = 2;
		int unitsPerSemester = 12;
		int currentYear = 2023;
		
		if (gpa >=3.5 && gpa<= 3.79) {
			System.out.println ("You will be graduating with distinction of Cum Laude.");
		}
		else if (gpa >=3.8 && gpa<= 3.99) {
			System.out.println ("You will be graduating with distinction of Magna Cum Laude.");
		}
		else if (gpa == 4.0) {
			System.out.println ("You will be graduating with distinction of Summa Cum Laude.");
		}
		
		
		
		
		if (academicYear.equals ("freshman") ||academicYear.equals ("1" )) {
			System.out.println ("You have " + (semestersInAcademicYear * 4) + " semesters left.");
			System.out.println ("You have " + ((unitsPerSemester * (semestersInAcademicYear*4))) + " units left.");
			System.out.println ("You will be graduating in class of " + (currentYear + 4));
		}	
			if (academicYear.equals ("Sophmore") ||academicYear.equals ("2" )) {
				System.out.println ("You have " + (semestersInAcademicYear * 3) + " semesters left.");
				System.out.println ("You have " + ((unitsPerSemester * (semestersInAcademicYear*3))) + " units left.");
				System.out.println ("You will be graduating in class of " + (currentYear + 3));
		}
			if (academicYear.equals ("Junior") ||academicYear.equals ("3" )) {
				System.out.println ("You have " + (semestersInAcademicYear * 2) + " semesters left.");
				System.out.println ("You have " + ((unitsPerSemester * (semestersInAcademicYear*2))) + " units left.");
				System.out.println ("You will be graduating in class of " + (currentYear + 2));
		}
			if (academicYear.equals ("Senior") ||academicYear.equals ("4" )) {
				System.out.println ("You have " + (semestersInAcademicYear) + " semesters left.");
				System.out.println ("You have " + ((unitsPerSemester * (semestersInAcademicYear))) + " units left.");
				System.out.println ("You will be graduating in class of " + (currentYear + 1));
		}	
			
			
			
	
	}
	
}

/*			System.out.println ("\n Academic Year is : " + academicYear + "GPA is : " + gpa);*/



