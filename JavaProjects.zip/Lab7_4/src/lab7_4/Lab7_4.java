package lab7_4;

public class Lab7_4 {
	public static void main(String[] args) {
        Administrator administrator = new Administrator("Ether Yale", "333-44-5555", 2300.0,
                "Julie Roberts", "Vice President", "Jason Karl");

        System.out.println("Administrator before reading data:\n" + administrator);

        administrator.readData();

        System.out.println("\nAdministrator after reading data:\n" + administrator);
    }
}