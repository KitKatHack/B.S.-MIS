package lab7_4;
import java.util.Scanner;
class Administrator extends SalariedEmployee {
    private String title;
    private String responsibility;
    private String supervisor;

    public Administrator(String name, String socialSecurityNumber, double weeklySalary,
                         String title, String responsibility, String supervisor) {
        super(name, socialSecurityNumber, weeklySalary);
        this.title = title;
        this.responsibility = responsibility;
        this.supervisor = supervisor;
    }

    public String getTitle() {
        return title;
    }

    public String getResponsibility() {
        return responsibility;
    }

    public String getSupervisor() {
        return supervisor;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setResponsibility(String responsibility) {
        this.responsibility = responsibility;
    }

    public void setSupervisor(String supervisor) {
        this.supervisor = supervisor;
    }

    public void readData() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter administrator's title: ");
        title = scanner.nextLine();
        System.out.print("Enter responsibility: ");
        responsibility = scanner.nextLine();
        System.out.print("Enter supervisor's name: ");
        supervisor = scanner.nextLine();

        System.out.print("Enter employee name: ");
        setName(scanner.nextLine());
        System.out.print("Enter SSN: ");
        setSocialSecurityNumber(scanner.nextLine());
        System.out.print("Enter weekly salary: ");
        setWeeklySalary(scanner.nextDouble());
    }

    public String toString() {
        return "Administrator: " + title +
                "\nResponsibility: " + responsibility +
                "\nSupervisor: '" + supervisor +
                "\n" + super.toString();
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        if (!super.equals(obj)) return false;
        Administrator that = (Administrator) obj;
        return title.equals(that.title) &&
        		responsibility.equals(that.responsibility) &&
                supervisor.equals(that.supervisor);
    }
}