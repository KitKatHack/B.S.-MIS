package lab7_4;
class SalariedEmployee {
    private String name;
    private String ssn;
    private double weeklySalary;

    public SalariedEmployee(String name, String ssn, double weeklySalary) {
        this.name = name;
        this.ssn = ssn;
        this.weeklySalary = weeklySalary;
    }

    public String getName() {
        return name;
    }

    public String getSocialSecurityNumber() {
        return ssn;
    }

    public double getWeeklySalary() {
        return weeklySalary;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSocialSecurityNumber(String ssn) {
        this.ssn = ssn;
    }

    public void setWeeklySalary(double weeklySalary) {
        this.weeklySalary = weeklySalary;
    }

    public String toString() {
        return "\nSalariedEmployee: " +
                "\nname: " + name +
                "\nSSN: " + ssn +
                "\nWeekly Salary: " + weeklySalary;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        SalariedEmployee that = (SalariedEmployee) obj;
        return ssn.equals(that.ssn);
    }
}