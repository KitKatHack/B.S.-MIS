/**
 * 
 */
/**
 * 
 */
module Lab_3pt2 {
}