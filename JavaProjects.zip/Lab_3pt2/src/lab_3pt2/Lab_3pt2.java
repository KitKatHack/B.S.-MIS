package lab_3pt2;
	import java.util.Random;
public class Lab_3pt2 {
	public static void main (String[] args) {
		
		
			Random randomGenerator = new Random ();
			
			int win = 0;
			int lose = 0;
		
			
			for (int i = 0; i < 10000; i++) {
				int roll_1 = randomGenerator.nextInt(1,7);
				int roll_2 = randomGenerator.nextInt(1,7);
				int sumRoll = roll_1 + roll_2;
		if (sumRoll == 7 || sumRoll == 11) {
			win++;	
		}
		
		else if (sumRoll == 2 || sumRoll == 3 || sumRoll == 12) {
			lose++;
		}
		
			else {
			int point = sumRoll;
			while (true) {
				int newRoll_1 = randomGenerator.nextInt (1,7);
				int newRoll_2 = randomGenerator.nextInt (1,7);
				int newSum = newRoll_1 + newRoll_2;
				if (newSum == point) {
					win++;
					break;
				}
				else if (newSum == 7) {
					lose++;
					break;
				}
					
				}
			}	
		}	
		double oddsOfWinning = (double)win/(win+lose);
		System.out.println ("You have played 10,000 games of craps and won " + win + " times and lost " + lose + " times.");
		System.out.println ("Your probability of winning are " + (oddsOfWinning*100) + " %.");
	
		if (oddsOfWinning > .50) {
			System.out.println ("The odds are in the player's favor.");
		}
		else {
			System.out.println ("The odds are in the house's favor.");
		}
	
	}
}



