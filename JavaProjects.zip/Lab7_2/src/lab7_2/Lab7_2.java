package lab7_2;

public class Lab7_2 {
	 public static void main(String[] args) {
	        Email email = new Email("Hello, this is an email!", "sender@example.com", "recipient@example.com", "Subject");
	        File file = new File("Hello, this is a file!", "/path/to/file.txt");

	        System.out.println(ContainsKeyword(email, "email"));
	        System.out.println(ContainsKeyword(file, "file"));
	        System.out.println(ContainsKeyword(email, "file"));
	        System.out.println(ContainsKeyword(file, "email"));
	    }

	    public static boolean ContainsKeyword(Document docObject, String keyword) {
	        return docObject.toString().contains(keyword);
	    }
	}