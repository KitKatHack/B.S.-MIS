package lab7_2;

class File extends Document {
    private String pathname;

    public File(String text, String pathname) {
        super(text);
        this.pathname = pathname;
    }


    public String getPathname() {
        return pathname;
    }

    public void setPathname(String pathname) {
        this.pathname = pathname;
    }

    public String toString() {
        return "Pathname: " + pathname + "\nText: " + text;
    }
}