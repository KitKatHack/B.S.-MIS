/**
 * 
 */
/**
 * 
 */
module Lab7_2 {
}