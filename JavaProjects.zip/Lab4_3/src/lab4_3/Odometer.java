package lab4_3;

public class Odometer {
	
	private double mileage;
	private double fuelEfficiency;
	private double totalFuel;

	
	public Odometer ( double fuelEfficiency) {
		this.mileage = 0.0;
		this.fuelEfficiency = fuelEfficiency;
		this.totalFuel = 0.0;

	}
	
			public void reset () {
				this.mileage = 0.0;
				this.totalFuel = 0.0;
			}
			public void setFuelEfficiency (double fuelEfficiency) {
				this.fuelEfficiency = fuelEfficiency;
			}
			public void addMileage (double miles) {
				this.mileage += miles;
				this.totalFuel += miles/fuelEfficiency;
			}
			
			public double totalFuelConsumption () {
				return totalFuel;
			}
			
	
}
			
			
			
			
			
			/*(fuel, mileage))	{
	this.fuel = monthString(month);
	this.mileage = fuel;
	public void writeOutput() {
		System.out.println(fuel + " " + mileage + " ");
	}
	public void

}
	
	
	
/*import java.util.Scanner;
	public class DateFifthTry
{
	 private String month;
	 private int day;
	 private int year; //a four digit number.
	 public void writeOutput()
	 {
	 System.out.println(month + " " + day + ", " + year);
	 }
	 public void*/