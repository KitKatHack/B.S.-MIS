package lab4_3;

public class Lab4_3 {
	public static void main (String[]args) {

		Odometer trip1 = new Odometer(50);
		trip1.addMileage(100);
		System.out.println("Fuel consumed for Trip 1 in gallons is " + trip1.totalFuelConsumption());
		
		Odometer trip2 = new Odometer(60);
		trip2.addMileage(150);
		System.out.println("Fuel consumed for Trip 2 in gallons is " + trip2.totalFuelConsumption());
		
		trip2.reset();
		trip2.addMileage(70);
		System.out.println("Fuel consumed after reseting Trip 2 in gallons is " + trip2.totalFuelConsumption());

	
	
	}
}
