package exam2Practice1_2;
	import java.util.Scanner;
public class Exam2Practice1_2 {
	public static void main (String [] args) {
		Scanner myObject = new Scanner (System.in);
		
		
		System.out.println ("Please indicate your age.");
			double humanAge = myObject.nextDouble();
		System.out.println ("Please indicate your dog's age.");
			double dogAge = myObject.nextDouble();
		
		double dogConversion = dogAge * 7;
		double nextYearHuman = humanAge + 1;
		double nextYearDog = dogConversion + 1;

		System.out.println ("Next year you will be " + nextYearHuman + " years old.");
		System.out.println ("Next year your dog will be " + nextYearDog + " years old in human years.");

		
		
		/*while (nextYearHuman >= 0 && nextYearHuman <= 50) {
			nextYearHuman++;
			System.out.println ("In " + nextYearHuman + " years you will be " + nextYearHuman + " years old.");
		}
		
		while (nextYearDog >= 0 && nextYearDog <= 150) {
			nextYearDog++;
			System.out.println ("In " + nextYearDog + " years your dog will be " + nextYearDog + " years old.");
			}*/
		
		while ((nextYearHuman >= 0 && nextYearHuman <= 50) && (nextYearDog >= 0 && nextYearDog <= 150)) {
			nextYearHuman++;
			System.out.println ("In " + nextYearHuman + " years you will be " + nextYearHuman + " years old.");
	
			nextYearDog++;
			System.out.println ("In " + nextYearDog + " years your dog will be " + nextYearDog + " years old.");
			}
		
		
		/*while (humanAge <= 50) {*/
		/*while (humanAge>=0 && humanAge<=50) {
			int nextYear = 1;
			nextYearHuman++;
			System.out.println ("In " + nextYear + " years you will be " + nextYearHuman + " years old.");
		}
		
		/*while (dogAge <= 150) {*/
	/*while (dogAge>=0 && dogAge<=150) {
			int nextYear = 1;
			nextYearDog++;
			System.out.println ("In " + nextYear + " years your dog will be " + nextYearDog + " years old.");
		}*/
		
		
		
	}
}
