/**
 * 
 */
/**
 * 
 */
module Lab_3pt6 {
}