package lab_3pt6;
import java.util.Scanner;
public class Lab_3pt6 {
	public static void main (String [] args) {
		Scanner fibonacci = new Scanner(System.in);

		int populationStart, days;

		System.out.println ("Please enter start size of crud population.");
			String crudPopulation = fibonacci.next();
			 
			 
			
			int n1 = 0, n2 = 1;



			for (int i = 1; i > 0; ++i)
			{
			System.out.print(n1 + " ");
		
			int sum = n1 + n2;
			n1 = n2;
			n2 = sum % 5;
			
			}
	}
}
