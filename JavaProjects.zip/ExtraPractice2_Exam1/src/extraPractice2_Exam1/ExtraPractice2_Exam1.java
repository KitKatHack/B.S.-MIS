package extraPractice2_Exam1;
	import java.util.Scanner;

public class ExtraPractice2_Exam1 {
	public static void main (String [] args) {
		 Scanner Keyboard = new Scanner (System.in);
	
		 
		 System.out.println ("Please insert average time it takes to run 5 miles in seconds");
		 	double seconds = Keyboard.nextDouble();
		
		 	
		 	double hour = seconds/3600;
		 	double min = (seconds % 3600)/60;
		 	double sec = (seconds % 3600) % 60;
		 	
		 	
		
		 			
		 	 System.out.println ("You ran ");
			 System.out.printf ("%8.2f", hour);
			 System.out.println (" in hours ");
		 	
			 System.out.println (" and ");
			 System.out.printf ("%8.2f", min);
			 System.out.println (" in minutes ");
			 
			 System.out.println ("You ran ");
			 System.out.printf ("%12.2f", sec);
			 System.out.println (" in seconds.");

			

			 
		 	
		 	
		 	

		 System.out.println ("You ran " + hour + " in hours " + min + " in minutes " + sec + " in seconds.");	
		
		
		 
	}

}
