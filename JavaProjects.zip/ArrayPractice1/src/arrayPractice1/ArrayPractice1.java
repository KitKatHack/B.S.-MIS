package arrayPractice1;
import java.util.Random; //used for dog practice//
public class ArrayPractice1 {
	public static void main(String[]args) {
	
	double[] practiceArray1 = new double[5];
	
	practiceArray1[0] = 5.5;
	practiceArray1[1] = 8.8;
	practiceArray1[2] = 4.4;
	practiceArray1[3] = 1.1;
	practiceArray1[4] = 2.2;

	System.out.println(practiceArray1.length);
	
	for(int i = 0; i < practiceArray1.length; i++) {
		System.out.println("Array value at index" + i + " = " + practiceArray1[i]);

		
	}
	
	String[] studentNames = new String[6];
		studentNames[0] = "Rigo";
		studentNames[1] = "Nick";
		studentNames[2] = "Lenny";
		studentNames[3] = "Ryan";
		studentNames[4] = "Diana";
		studentNames[5] = "Diana";

		int size = studentNames.length;
		
		
			for(int a = 0; a < studentNames.length-1; a++) {
				if(studentNames[a] == studentNames [a+1]) {
					System.out.println("This is a duplicate!");
					studentNames[a+1] = " ";
					System.out.println("New Value: " + studentNames[a+1]);
				} else {
						System.out.println("Student name is: " + studentNames[a]);
						
					}
				}

			//start using import.java.util.Random//
	Random rand = new Random();

	int[] dogs = new int [8];
	int minimum = dogs[0];
	int maximum = dogs[0];
	
		for(int i = 0; i < dogs.length; i++) {
			dogs[i] = rand.nextInt(10);
	
			if(dogs[i] < minimum) {
				minimum = dogs[i];
			}
			
			if(dogs[i] > maximum) {
				maximum = dogs[i];
	
			}
			System.out.println("Value at Dogs [index " + i + "] = " + dogs[i]);
	}
	
			System.out.println("Min. Value: " + minimum);
			System.out.println("Max Value: " + maximum);	
			
	}
}
