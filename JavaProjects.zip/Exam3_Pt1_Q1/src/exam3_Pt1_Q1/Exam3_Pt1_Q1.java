package exam3_Pt1_Q1;

public class Exam3_Pt1_Q1 {
	public static void main (String []args) {
	int size = 50;

	System.out.println("Array:");
	double[] array = new double [size];
		for (int i =0; i <= size; i++) {
			System.out.println(i);
		}
		
		System.out.println("\nOdd Array:");
		double[] odd = new double [size];
		for (int i =0; i <= size; i++) {
			System.out.println(i++);
		}
		
		
		System.out.println("\nEven Array:");
		double[] even = new double [size];
		for (int i =1; i <= size; i++) {
			if (i > 1)
			System.out.println(i - 1);
		}
	}}