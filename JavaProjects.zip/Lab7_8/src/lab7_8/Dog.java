package lab7_8;

class Dog extends Pet {
    private String breed;

    public Dog(String name, int age, String breed) {
        super(name, age);
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }


    public double acepromazine() {
        return getAge() <= 2 ? 0.03 * getWeight() : 0.05 * getWeight();
    }

    public double carprofen() {
        return 0.5 * getWeight();
    }

    private double getWeight() {
        return 10.0;
    }

    public String toString() {
        return "Dog: "+ getName() +
                "\nAge: " + getAge() +
                "\nbreed: " + breed;
    }
}
