package lab7_8;

class Cat extends Pet {
    private boolean isIndoor;

    public Cat(String name, int age, boolean isIndoor) {
        super(name, age);
        this.isIndoor = isIndoor;
    }

    public boolean isIndoor() {
        return isIndoor;
    }

  
    public double acepromazine() {
        return 0.002 * getWeight();
    }

    public double carprofen() {
        return 0.08 * getWeight();
    }

    private double getWeight() {
        return 5.0;
    }

    public String toString() {
        return "Cat: "+ getName() +
               "\nAge: " + getAge() +
               "\nIs cat indoor? " + isIndoor;
        
    }
}