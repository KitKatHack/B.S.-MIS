package lab7_8;

class Pet {
    private String name;
    private int age;
    
    public Pet(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double acepromazine() {
        return 0;
    }

    public double carprofen() {
        return 0;
    }

    public String toString() {
        return "Pet{name='" + name + "', age=" + age + '}';
    }
}