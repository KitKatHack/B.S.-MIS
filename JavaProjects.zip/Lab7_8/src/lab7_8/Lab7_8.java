package lab7_8;
public class Lab7_8 {
	  public static void main(String[] args) {
	        Dog dog = new Dog("Diesel", 3, "Rottweiler");
	        Cat cat = new Cat("KittySoftPaws", 5, true);

	        System.out.println(dog);
	        System.out.println("Acepromazine dosage for " + dog.getName() + ": " + dog.acepromazine());
	        System.out.println("Carprofen dosage for " + dog.getName() + ": " + dog.carprofen());

	        System.out.println();

	        System.out.println(cat);
	        System.out.println("Acepromazine dosage for " + cat.getName() + ": " + cat.acepromazine());
	        System.out.println("Carprofen dosage for " + cat.getName() + ": " + cat.carprofen());
	    }
	}
