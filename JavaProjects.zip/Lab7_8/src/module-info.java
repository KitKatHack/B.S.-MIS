/**
 * 
 */
/**
 * 
 */
module Lab7_8 {
}