package practice1_Exam1Pt1;

public class Practice1_Exam1Pt1 {
	public static void main (String[] args) {
		
	
		double initial = 4000;
		double int_rate = 8;
		double no_of_yrs = 3;
		
		
		double Simpleinterest = (initial * int_rate * no_of_yrs)/100;

		
		System.out.println("Michael will pay $" + Simpleinterest + " in interest over 3 years.");
		
		
	}
 
}