package lab4_2;

public class Lab4_2 {
	public static void main (String[]args) {
		
		
	Fraction fraction = new Fraction(15, 75);
		
		
	System.out.println("Fraction: " + fraction);
	System.out.println("Fraction Value : " + fraction.getCalc());
	
	
	fraction.reduce();
	System.out.println("Fraction to lowest terms: " + fraction);


		
		
		
	}

}
