package lab4_2;
	import java.util.Scanner;
public class Fraction {
	Scanner keyboard = new Scanner(System.in);

	private int numerator;
	private int denominator;

	
	public Fraction (int numerator, int denominator) {
		if (denominator == 0) {
			System.out.println("Invalid operation.");
			}
			this.numerator = numerator;
			this.denominator = denominator;
	}		
		
	
	public void setNumerator(int numerator) {
		this.numerator = numerator;
	}
	public void setDenominator(int denominator) {
		if (denominator == 0) {
			System.out.println("Invalid operation.");
		}
		this.denominator = denominator;
	}

	
	
	public double getCalc() {
		return (double) numerator/denominator;
	}
	private double calc (double a, double b) {
		if (b == 0){
			return a;
		}
		return calc(b, a % b);
	}
		
	
	
		public void reduce() {
			double calc = calc(numerator,denominator);
			numerator /= calc;
			denominator /= calc;
		}
		public String toString() {
			return numerator + "/" + denominator;
		}
	}