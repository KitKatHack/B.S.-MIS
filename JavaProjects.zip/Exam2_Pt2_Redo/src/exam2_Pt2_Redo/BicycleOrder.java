package exam2_Pt2_Redo;

public class BicycleOrder {
		 private int numOfBicycles;
		    private Bicycle bicycle1;
		    private Bicycle bicycle2;
		    private Bicycle bicycle3;

		    public BicycleOrder() {
		        this.numOfBicycles = 0;
		    }

		    public void setNumOfBicycles(int numOfBicycles) {
		        if (numOfBicycles >= 1 && numOfBicycles <= 3) {
		            this.numOfBicycles = numOfBicycles;
		        } }

		    public void setBicycle1(Bicycle bicycle1) {
		        this.bicycle1 = bicycle1;
		    }

		    public void setBicycle2(Bicycle bicycle2) {
		        if (numOfBicycles >= 2) {
		            this.bicycle2 = bicycle2;
		        }
		    }

		    public void setBicycle3(Bicycle bicycle3) {
		        if (numOfBicycles == 3) {
		            this.bicycle3 = bicycle3;
		        } 
		    }

		    public double calcTotal() {
		        double totalCost = 0.0;

		        if (bicycle1 != null) {
		            totalCost += bicycle1.getCost();
		        }

		        if (bicycle2 != null) {
		            totalCost += bicycle2.getCost();
		        }

		        if (bicycle3 != null) {
		            totalCost += bicycle3.getCost();
		        }

		        return totalCost;
		    }}
