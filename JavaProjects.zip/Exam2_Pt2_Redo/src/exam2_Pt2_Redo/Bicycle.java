package exam2_Pt2_Redo;

public class Bicycle {
		    private String bicycle;
		    private double cost;

		    public Bicycle(String bicycle, double cost) {
		        this.bicycle = bicycle;
		        this.cost = cost;
		    }

		    public double getCost() {
		        return cost;
		    }
		}
