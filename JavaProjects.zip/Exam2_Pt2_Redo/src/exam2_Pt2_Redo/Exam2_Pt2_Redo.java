package exam2_Pt2_Redo;

public class Exam2_Pt2_Redo {
	public void main (String [] args) {
		
		 BicycleOrder order = new BicycleOrder();

	        Bicycle bicycle1 = new Bicycle("bicycle1", 100.0);
	        order.setBicycle1(bicycle1);

	        Bicycle bicycle2 = new Bicycle("bicycle2", 150.0);
	        order.setBicycle2(bicycle2);

	        order.setNumOfBicycles(2);

	        System.out.println("Bicycle Order Cost: $" + order.calcTotal());		 



}}
