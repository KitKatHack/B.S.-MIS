package lab4_9;

public class AnimalSpecies {

	private String name;
	private int population;
	private double growthRate;
	
	public AnimalSpecies(String name, int population, double growthRate) {
		this.name = name;
		this.population = population;
		this.growthRate = growthRate;
	}
	
	
	public AnimalSpecies(String name){
		this(name, 0, 0.0);
	}
	public String getname() {
		return name;
	}
	public int getpopulation() {
		return population;
	}
	public double getgrowthRate() {
		return growthRate;
	}
	
	
	
	
	public void setpopulation(int population) {
		this.population = population;
	}
	public void setgrowthRate(double growthRate) {
		this.growthRate = growthRate;
	}
	
	
	
	public String toString() {
		return "Species Name: " + name + "\nPopulation: " + population + "\nGrowth Rate: " + growthRate + "%";
	}
	
	
	
	public boolean equals(AnimalSpecies other) {
		return this.name.equals(other.name)&&
				this.population == other.population &&
				this.growthRate == other.growthRate;
	}
	public boolean endangered () {
		return growthRate < 0;
	}
	
	
	
	
	
}
