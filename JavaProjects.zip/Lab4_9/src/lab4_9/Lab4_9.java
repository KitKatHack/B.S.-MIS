package lab4_9;

public class Lab4_9 {
	public static void main (String[]args) {
		
		AnimalSpecies sheep = new AnimalSpecies("Sheep",1266000000,33);
		AnimalSpecies galapagosPeng = new AnimalSpecies("Galapagos Penguin");
			galapagosPeng.setpopulation (3000);
			galapagosPeng.setgrowthRate (-60);
		
	System.out.println("Species Name: " + sheep.getname());
	System.out.println("Population: " + sheep.getpopulation());
	System.out.println("Growth Rate: " + sheep.getgrowthRate() + "%");

	System.out.println("\nIs Galapagos Penguin population endangered?\n" + galapagosPeng.endangered());

		
	}
}
