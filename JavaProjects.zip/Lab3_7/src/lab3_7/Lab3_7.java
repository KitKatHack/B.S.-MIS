package lab3_7;
import java.util.Scanner;
import java.lang.Math;

public class Lab3_7 {
	public static void main (String[] args) {
	Scanner keyboard = new Scanner(System.in);
	
	
	System.out.println ("Do you wish to perform another calculation? Please enter 'Yes' or 'No'.");
	String continueProgram = keyboard.nextLine();
	
	
	
	if (continueProgram.equalsIgnoreCase ("yes")) {
		
		System.out.println ("Please provide positive value for 'x' :");
		double x = keyboard.nextDouble();		
		
		System.out.println ("Please provide positive value for 'n' :");
		double n = keyboard.nextDouble();
		
		
		
		double factorial = 1;
		double numerator = 1;
				
		for (int i = 1; i <= n; i++ ) {
			 numerator = factorial + x + Math.pow(x, factorial);
			 double newValue = numerator/factorial;
			 factorial = 1 + Math.pow(x, n);
				double sum =+ newValue;
			System.out.println (sum);	
		}
	}
	
		else {
			System.out.println ("You have chosen not to continue using program.");
		
	}
	
	}
}