package exam3_Pt2;
 class VeggiePizza extends Pizza {

	 private int veggieToppings;

	 public VeggiePizza(String pizzaSize, int cheeseToppings, int veggieToppings) {
			super(pizzaSize, cheeseToppings);
			this.veggieToppings = veggieToppings;
		}
	 
		public int getVeggieToppings() {
			return veggieToppings;
		}
		public void setVeggieToppings(int veggieToppings) {
			this.veggieToppings = veggieToppings;
		}
	 
		public void pizzaDetails() {
			super.pizzaDetails();
			System.out.println("\nVeggie Toppings: " + veggieToppings);

	}
	
}
