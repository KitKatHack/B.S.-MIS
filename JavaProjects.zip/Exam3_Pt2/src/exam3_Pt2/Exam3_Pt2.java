package exam3_Pt2;
public class Exam3_Pt2 {
	public static void main (String [] args) {
		
		Pizza meatPizza1 = new Pizza("Large", 4, 2, 1);
		Pizza meatPizza2 = new Pizza("Small", 3, 4, 5);
		Pizza veggiePizza1 = new Pizza("Medium", 3, 2, 1);
		Pizza veggiePizza2 = new Pizza("Large", 4, 0, 2);

		System.out.println("Meat Pizza 1:");
		meatPizza1.pizzaDetails();
		
		System.out.println("Meat Pizza 2:");
		meatPizza2.pizzaDetails();
		
		System.out.println("Veggie Pizza 1:");
		veggiePizza1.pizzaDetails();
		
		System.out.println("Veggie Pizza 2:");
		veggiePizza2.pizzaDetails();

	
	}
}
