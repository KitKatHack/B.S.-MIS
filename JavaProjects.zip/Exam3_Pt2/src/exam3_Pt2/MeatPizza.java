package exam3_Pt2;
 class MeatPizza extends Pizza {
	
	 private int meatToppings;

	 public MeatPizza(String pizzaSize, int cheeseToppings, int meatToppings) {
		super(pizzaSize, cheeseToppings);
		this.meatToppings = meatToppings;
	}

	 
	 
		public int getMeatToppings() {
			return meatToppings;
		}
		public void setMeatToppings(int meatToppings) {
			this.meatToppings = meatToppings;
		}
		
		public void pizzaDetails() {
			super.pizzaDetails();
		System.out.println("\nMeat Toppings: " + meatToppings);
	}
	 
	 
}
