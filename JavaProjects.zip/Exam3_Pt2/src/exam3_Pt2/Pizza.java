package exam3_Pt2;
 public class Pizza{
		
	private String pizzaSize;
	private int cheeseToppings;
	
	public Pizza(String pizzaSize, int cheeseToppings) {
		this.pizzaSize = pizzaSize;
		this.cheeseToppings = cheeseToppings;

	}
	public String getPizzaSize() {
		return pizzaSize;
	}
	public void setPizzaSize(String pizzaSize) {
		this.pizzaSize = pizzaSize;
	}
	
	
	public int getCheeseToppings() {
		return cheeseToppings;
	}
	public void setCheeseToppings(int cheeseToppings) {
		this.cheeseToppings = cheeseToppings;
	}
	

	
 public void pizzaDetails() {
		System.out.println("\nPizza Size: " + pizzaSize + "\nCheese Toppings: " + cheeseToppings);

	
}}
