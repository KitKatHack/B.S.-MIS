/**
 * 
 */
/**
 * 
 */
module Lab7_6 {
}