package lab7_6;

class Vehicle {
    private String manufacturer;
    private int cylinders;
    private Person owner;

    public Vehicle(String manufacturer, int cylinders, Person owner) {
        this.manufacturer = manufacturer;
        this.cylinders = cylinders;
        this.owner = new Person(owner);
    }


    public String toString() {
        return "Vehicle: " +
                "\nManufacturer: " + manufacturer +
                "\nCylinders: " + cylinders +
                "\n" + owner;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        Vehicle vehicle = (Vehicle) other;
        return cylinders == vehicle.cylinders &&
               manufacturer.equals(vehicle.manufacturer) &&
               owner.equals(vehicle.owner);
    }
}