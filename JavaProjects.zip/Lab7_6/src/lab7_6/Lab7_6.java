package lab7_6;

public class Lab7_6 {
	    public static void main(String[] args) {

	        Person person = new Person("Harrison Ford");

	        Vehicle vehicle = new Vehicle("Honda", 4, person);
	        System.out.println(vehicle);

	        Truck truck = new Truck("Ram", 6, person, 3.5, 5000);
	        System.out.println("\n" +truck);
	}}