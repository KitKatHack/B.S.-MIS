package lab7_6;

	public class Person {
	    private String name;

	    public Person() {
	    }

	    public Person(String theName) {
	        this.name = theName;
	    }

	    public Person(Person theObject) {
	        this.name = theObject.name;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String theName) {
	        this.name = theName;
	    }

	    public String toString() {
	        return "Person: " + name;
	    }

	    public boolean equals(Object other) {
	        if (this == other) {
	            return true;
	        }
	        if (other == null || getClass() != other.getClass()) {
	            return false;
	        }
	        Person person = (Person) other;
	        return name.equals(person.name);
	    }
	}