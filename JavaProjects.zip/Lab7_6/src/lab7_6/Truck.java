package lab7_6;
class Truck extends Vehicle {
    private double loadCapacity;
    private int towingCapacity;

    public Truck(String manufacturer, int cylinders, Person owner, double loadCapacity, int towingCapacity) {
        super(manufacturer, cylinders, owner);
        this.loadCapacity = loadCapacity;
        this.towingCapacity = towingCapacity;
    }

    public String toString() {
        return super.toString() +
                "\nLoad Capacity: " + loadCapacity + " tons" +
                "\nTowing Capacity: " + towingCapacity + " pounds";
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        Truck truck = (Truck) other;
        return super.equals(other) &&
               loadCapacity == truck.loadCapacity &&
               towingCapacity == truck.towingCapacity;
    }
}
