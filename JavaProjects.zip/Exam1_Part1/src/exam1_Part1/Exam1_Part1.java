package exam1_Part1;
	import java.util.Scanner;
public class Exam1_Part1 {
	public static void main (String [] args) {
		Scanner Keyboard = new Scanner (System.in);
	
		
		System.out.println ("Insert principle amount:");
		double principle = Keyboard.nextDouble();

		System.out.println ("Insert interest rate amount:");
		double interest = Keyboard.nextDouble();

		System.out.println ("Insert number of years:");
		double years = Keyboard.nextDouble();


		double simpleInterest = ((principle * interest * years)/100);
	

		System.out.printf("Based on the information you provided, you will pay $" + "%8.2f", simpleInterest);
		
	
	}
}
