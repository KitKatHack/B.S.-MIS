package lab6_3;
	import java.util.Scanner;
public class Lab6_3 {
	public static void main (String[]args) {
	
        Scanner scanner = new Scanner(System.in);
		       do {
	           double[] avgRainfall = new double[12];
	           inputAvgRainfall(scanner, avgRainfall);


	           int currentMonth;
		       do {
		              System.out.print("Enter the current month (1 - 12): ");
		              currentMonth = scanner.nextInt();
	         } while (currentMonth < 1 || currentMonth > 12);

		       double[] actualRainfall = new double[12];
		       inputActualRainfall(scanner, currentMonth, actualRainfall);

		          
		       		table(avgRainfall, actualRainfall);

		            System.out.print("Do you want to calculate again? (yes/no): ");
		        } while (scanner.next().equalsIgnoreCase("yes"));

		        System.out.println("Program ended.");
		        scanner.close();
		    }

		    private static void inputAvgRainfall(Scanner scanner, double[] avgRainfall) {
		        System.out.println("Please enter the average monthly rainfall for each month:");
		        for (int i = 0; i < avgRainfall.length; i++) {
		            System.out.print("Month " + (i + 1) + ": ");
		            avgRainfall[i] = scanner.nextDouble();
		        }
		    }

		    private static void inputActualRainfall(Scanner scanner, int currentMonth, double[] actualRainfall) {
		        System.out.println("Please ennter the actual monthly rainfall for the previous 12 months:");
		        for (int i = 0; i < actualRainfall.length; i++) {
		            int month = (currentMonth - 1 - i + 12) % 12 + 1;
		            System.out.print("Month " + month + ": ");
		            actualRainfall[i] = scanner.nextDouble();
		        }
		    }

		    private static void table(double[] avgRainfall, double[] actualRainfall) {
		        System.out.printf("%-15s%-15s%-20s\n", "Month", "Actual Rainfall", "Deviation from Avg");
		        for (int i = 0; i < avgRainfall.length; i++) {
		            String monthName = getMonthName(i + 1);
		            double deviation = actualRainfall[i] - avgRainfall[i];
		            System.out.printf("%-15s%-15.2f%-20.2f\n", monthName, actualRainfall[i], deviation);
		        }
		    }

		    private static String getMonthName(int month) {
		        switch (month) {
		            case 1: return "January";
		            case 2: return "February";
		            case 3: return "March";
		            case 4: return "April";
		            case 5: return "May";
		            case 6: return "June";
		            case 7: return "July";
		            case 8: return "August";
		            case 9: return "September";
		            case 10: return "October";
		            case 11: return "November";
		            case 12: return "December";
		            default: return "Invalid Month";
		        }
		    }
		}
		
		
		
		
		
		/*Scanner keyboard = new Scanner (System.in);

	System.out.println("Compute data analysis? Indicate 'yes' or 'no': ");
	String analysis = keyboard.next().toLowerCase();
	
	if (analysis.equals("no")){
   	 System.exit(0);
	}
	
	 else if (analysis.equals("yes")){	
		System.out.println("Please input the month we are in (1-12): ");
		int month = keyboard.nextInt();
		
		 switch (month) {
		case 1: 
			System.out.println("Month is: January");
			break;
		case 2: 
			System.out.println("Month is: February");
			break;
		case 3: 
			System.out.println("Month is: March");
			break;
		case 4: 
			System.out.println("Month is: April");
			break;
		case 5: 
			System.out.println("Month is: May");
			break;
		case 6: 
			System.out.println("Month is: June");
			break;
		case 7: 
			System.out.println("Month is: July");
			break;
		case 8: 
			System.out.println("Month is: August");
			break;
		case 9: 
			System.out.println("Month is: September");
			break;
		case 10: 
			System.out.println("Month is: October");
			break;
		case 11: 
			System.out.println("Month is: November");
			break;
		case 12: 
			System.out.println("Month is: December");		
			break;
		 }
		
		for (int c = 1; c > month; c++) {
			int lastMonth = (month-1-c+12) % 12;
			String monthName = Integer.toString(month);
				//System.out.println(month + (lastMonth +1));//

		}
		Scanner object = new Scanner (System.in);
		for (int a  = 0; a < 12; a++) {
			int lastMonth = (month-1-a+12) % 12;
			String monthName = String.valueOf(lastMonth+1);
		
			
			double [] avgRain = new double [12];
				System.out.println("Please enter average rainfall for month " + (monthName) + ": ");
				avgRain[a]= object.nextDouble();
				
		
		double [] rainfall = new double[12];
			System.out.println("Please input rainfall for month " + monthName + ": ");
			rainfall[a] = object.nextDouble();
		
	
		System.out.println("\nRainfall Analysis for Month: " + monthName);
		System.out.printf("\nAverage: " + avgRain[a]);
		System.out.printf("\nActual: " + rainfall[a]);
		System.out.printf("\nDeviation from Average = " + (avgRain[a] - rainfall[a]));
		break;*/
	
		
		 
	//	System.out.printf("%-15s%-15s%-20s\n", "Actual" , "Deviation from Average");//

		
		/*for (int b = 0; b < 12; b++) {
			String monthName = name(b+1);
			double deviation = (rainfall[a] - avgRain[a]);
			System.out.printf("%-15.0s%-15.2f%-20.2f\n", monthName , rainfall[a], deviation);*/
	//}}}}
	





		/*
		else {
		
			/*
		double [] rainfall = new double[12];
		for (int i  = 0; i < 12; i++) {
			int lastMonth = (month-1-i+12) % 12;
			
			System.out.println("Rainfall Analysis per Month:");
			System.out.printf("%-15s%-15s%-20s\n", "Month", "Actual" ,  "Deviation from Average");
		}	
			
			
		double [] avgRain = new double [12];
		for (int i = 0; i <12; i++) {
			System.out.println("Please enter avg. rainfall for month " + (i+1) + ": ");
			avgRain= keyboard.nextDouble(i);
		}*/

/*package lab6_3;

public class MonthName {

	
	private static String getMonth(int month) {
	switch (month) {
	case 1: 
		return "January";		
	case 2: 
		return "February";		
	case 3: 
		return "March";		
	case 4: 
		return "April";		
	case 5: 
		return "May";		
	case 6: 
		return "June";		
	case 7: 
		return "July";		
	case 8: 
		return "August";		
	case 9: 
		return "September";		
	case 10: 
		return "October";		
	case 11: 
		return "November";	
		case 12: 
		return "December";

	}
}}*/