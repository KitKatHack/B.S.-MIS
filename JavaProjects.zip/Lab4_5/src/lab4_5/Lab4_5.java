package lab4_5;

public class Lab4_5 {
	public static void main (String [] args) {
		Counter counter = new Counter();
		
		/*count 2 */
		counter.increase();
		counter.increase();
		counter.countDisplay();

		
		/*count 1 */
		counter.decrease();
		counter.countDisplay();

		
		/*count 0 */
		counter.reset();
		counter.countDisplay();
		
		
		/*equals statement */
		Counter alt = new Counter ();
		alt.increase();
		System.out.println(alt.equals(counter));
		
		alt.reset();
		System.out.println(alt.equals(counter));

		
	}
}
