package lab4_5;

public class Counter {
	
	private int count;
	
	public Counter() {
		count = 0;
	}
		public void reset() {
			count = 0;
		}
		public void increase() {
		count++;
}
		public void decrease() {
			if (count > 0) {
				count--;
	}
}
			public int getCount() {
				return count;
			}
		
			
			
		public void countDisplay() {
			System.out.println("Count: " + count);
		}
		public String toString() {
			return " Count: " + count;
		}
		/*toString method */

		
		
		
		
		public boolean equals(Object number) {
			if (this == number) {
				return true;
			}
			if (number == null || getClass() != number.getClass()) {
				return false;
		}
			Counter alt = (Counter) number;
			return count == alt.count;
			
		}
		
			
}
