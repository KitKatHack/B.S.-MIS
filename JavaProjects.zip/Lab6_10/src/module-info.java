/**
 * 
 */
/**
 * 
 */
module Lab6_10 {
}