package lab6_10;
	import java.util.Scanner;
public class Lab6_10 {
	public static void main (String[] args) {
		
		 char[][] ticTacToe = {
	                {'1', '2', '3'},
	                {'4', '5', '6'},
	                {'7', '8', '9'}
	        };

	        char player = 'X';
	        boolean win = false;

	        printBoard(ticTacToe);

	        for (int turn = 0; turn < 9 && !win; turn++) {
	            int move;
	            do {
	                move = getPlayerMove(player);
	            } while (!isValidMove(ticTacToe, move));

	            makeMove(ticTacToe, move, player);
	            printBoard(ticTacToe);

	            win = checkWin(ticTacToe, player);

	            player = (player == 'X') ? 'O' : 'X';
	        }

	        if (win) {
	            System.out.println("Player " + player + " wins!");
	        } else {
	            System.out.println("Draw.");
	        }
	    }

	    private static void printBoard(char[][] ticTacToe) {
	        System.out.println("TicTacToe Board:");
	        for (int i = 0; i < 3; i++) {
	            for (int j = 0; j < 3; j++) {
	                System.out.print(ticTacToe[i][j] + "  ");
	            }
	            System.out.println();
	        }
	        System.out.println();
	    }

	    private static int getPlayerMove(char play) {
	        Scanner game = new Scanner(System.in);
	        System.out.print("Player " + play + ": Choose position (1-9): ");
	        return game.nextInt();
	    }

	    private static boolean isValidMove(char[][] ticTacToe, int move) {
	        if (move < 1 || move > 9) {
	            System.out.println("Invalid: Enter valid position");
	            return false;
	        }

	        int row = (move - 1) / 3;
	        int collumn = (move - 1) % 3;

	        if (ticTacToe[row][collumn] == 'X' || ticTacToe[row][collumn] == 'O') {
	            System.out.println("Invalid: Choose another position.");
	            return false;
	        }

	        return true;
	    }

	    private static void makeMove(char[][] ticTacToe, int move, char play) {
	        int row = (move - 1) / 3;
	        int collumn = (move - 1) % 3;
	        ticTacToe[row][collumn] = play;
	    }

	    private static boolean checkWin(char[][] ticTacToe, char play) {
	        for (int i = 0; i < 3; i++) {
	            if ((ticTacToe[i][0] == play && ticTacToe[i][1] == play && ticTacToe[i][2] == play) ||
	                (ticTacToe[0][i] == play && ticTacToe[1][i] == play && ticTacToe[2][i] == play)) {
	                return true;
	            }
	        }

	        if ((ticTacToe[0][0] == play && ticTacToe[1][1] == play && ticTacToe[2][2] == play) ||
	            (ticTacToe[0][2] == play && ticTacToe[1][1] == play && ticTacToe[2][0] == play)) {
	            return true;
	        }

	        return false;
	    }
}
