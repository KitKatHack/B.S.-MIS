package labt3_12;
	import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
/*import java.io.FileReader;
	import java.io.BufferedReader;*/
	import java.util.Scanner;
public class Labt3_12 {
	public static void main (String[] args) throws FileNotFoundException {
		
		Scanner keyboard = new Scanner(System.in);

		
		File file = new File("/Users/sugarbabie/Desktop/file.txt");
		Scanner scan = new Scanner(file);
		
		/*int lineNumber = 0;
		
		try {
			BufferedReader br = new BufferedReader(new FileReader ("/Users/sugarbabie/Desktop/file.txt"));
			String line = null;
			
		
		/*int n = Integer.parseInt(br.readLine());
		while ( line = br.());
		*/
		
	
	
		System.out.println ("New calculation? 'Yes' or 'No'.");
		String newProgram = keyboard.nextLine();
		
		 if(newProgram.equalsIgnoreCase("no")) {
				System.out.println("Program exit.");
			
				
		 }
		 
		 else if (newProgram.equalsIgnoreCase ("yes")) {

		System.out.println ("Insert name : ");
		String name = keyboard.nextLine();
		
		/*Scanner inputStream = null;
		try {
			inputStream = new Scanner(new FileReader ("/Users/sugarbabie/Desktop/file.txt"));
	
		
		
		int n4 = inputStream.nextInt();
		int n5 = inputStream.nextInt();
		int n6 = inputStream.nextInt();
		int n7 = inputStream.nextInt();
		int n8 = inputStream.nextInt();
		int n9 = inputStream.nextInt();*/


			
			if (name.equalsIgnoreCase ("tom")) {
				
				double tom = 110 + (12*5) + (5*3);
				System.out.println("Tom's ideal bodyweight in pounds is " + tom);
				String n1 = scan.nextLine();
				String n2 = scan.nextLine();
				String n3 = scan.nextLine();
						System.out.println(n1);
						System.out.println(n2);
						System.out.println(n3);
					}
					
			else if (name.equalsIgnoreCase ("eaton")) {
				double eaton = 110 + (5*5);
				System.out.println("Eaton's ideal bodyweight in pounds is " + eaton);
				scan.nextLine();
				scan.nextLine();
				scan.nextLine();
				String n4 = scan.nextLine();
				String n5 = scan.nextLine();
				String n6 = scan.nextLine();
						System.out.println(n4);
						System.out.println(n5);
						System.out.println(n6);
				/*	System.out.println(scan.nextLine());
					System.out.println(scan.nextLine());
					System.out.println(scan.nextLine());*/
		}
		
			else if (name.equalsIgnoreCase ("cary")) {
			 	double cary = 110 + (5*11);
			 	System.out.println("Cary's ideal bodyweight in pounds is " + cary);
			 	scan.nextLine();
				scan.nextLine();
				scan.nextLine();
				scan.nextLine();
				scan.nextLine();
				scan.nextLine();
				String n7 = scan.nextLine();
				String n8 = scan.nextLine();
				String n9 = scan.nextLine();
						System.out.println(n7);
						System.out.println(n8);
						System.out.println(n9);
		
			}}}}
			
		
		/*while(scan.hasNextLine()) {
			System.out.println(scan.nextLine());*/
		
			
			
	

		
		
		/*		System.out.println (scan.nextLine());

		Scanner file = null;
		
		try {
			file = new Scanner(new FileInputStream("PathToFile"));
		}
			catch(FileNotFoundException e)
		{
			System.out.println ("File not found.");
			System.exit(0);
		}
		
		
		
		
		/*
		int height;
		String bodyweight;
		
		
		
		/*System.out.println ("New calculation? 'Yes' or 'No'.");
		String newProgram = keyboard.nextLine();
		
		if (newProgram.equalsIgnoreCase ("yes")) {
			
			System.out.println ("Please insert :");
			double x = keyboard.nextDouble();		
			
			System.out.println ("Please provide positive value for 'n' :");
			double n = keyboard.nextDouble();*/
		
