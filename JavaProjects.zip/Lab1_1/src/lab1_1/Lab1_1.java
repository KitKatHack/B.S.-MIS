package lab1_1;

public class Lab1_1 {
	public static void main (String[] args) {
	
		
		int running = 10;
		int basketball = 8;
		int sleeping = 1;
		int total = 19;
		
		double weightPerKilo = 150/2.2;
		
		int minran = 30;
		int minbasket = 30;
		int minsleep = 120;
		int mintotal = 260;		
		
		
		double ranformula = ((0.0175 * running * weightPerKilo) * minran);
		double basketformula = ((0.0175 * basketball * weightPerKilo) * minbasket);
		double sleepformula= ((0.0175 * sleeping * weightPerKilo) * minsleep);
		double totalcal = ((0.0175 * total * weightPerKilo)*mintotal);
		
		
		System.out.println("You have burned " + ranformula + " METs while running for 30 minutes at 6 MPH.");
		System.out.println("You have burned " + basketformula + " METs while playing basketball for 30 mintues.");
		System.out.println("You have burned " + sleepformula + " METs while sleeping for 6 hours.");
		System.out.println("In total you have burned " + totalcal + " METs in the last 7 hours.");
		
		
	}

}
//1073//

/*Running 6 MPH: 10 METS*/
/*Basketball: 8 METS*/
/*Sleeping: 1 MET*/
/*The number of calories burned per minute may be estimated using the following formula: */
/*Calories / Minute = 0.0175 × MET × 150*/

/*Write a program that calculates and outputs the total number of calories burned */
/*for a 150-pound person who runs 6 MPH for 30 minutes, plays basketball for 30 minutes, and then sleeps for 6 hours. */
/*One kilogram is equal to 2.2 pounds.*/
