/**
 * 
 */
/**
 * 
 */
module Lab1_1 {
}