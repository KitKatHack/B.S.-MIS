package lab3_8;

public class Lab3_8 {
	public static void main (String[] args) {

		System.out.println ("Cryparithmetic puzzle : TOO + TOO + TOO + TOO = GOOD");


	for (int T = 0; T <= 9;T++) {
		for (int O = 0; O <= 9;O++) {
			for (int G = 0; G <= 9;G++) {
				for (int D = 0; D <= 9;D++) {
					
				
			
			if (D == G | D == O | D == T | G == O | G == T | O == T) {
				continue;
			}
				else if ( 400 * T + 40 * O + 4 * O == 1000*G + 100*O + 10 * O + D)
					System.out.println ("T = " + T + ", O = " + O + ", G = " + G + ", D = " + D);
				{
			}
	}
	}
	 
	 
	 
	 
	 
	
			}}


	}
}






/* 4 loops for each letter 0-9
if statement -if they're equal*/