/**
 * 
 */
/**
 * 
 */
module Lab7_5 {
}