package lab7_5;
import java.util.Objects;

class SalariedEmployee {
    private String name;
    private double salary;

    public SalariedEmployee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SalariedEmployee)) {
            return false;
        }
        SalariedEmployee otherEmployee = (SalariedEmployee) obj;
        return name.equals(otherEmployee.name) && salary == otherEmployee.salary;
    }

    public String toString() {
        return "Name: " + name + "\nSalary: " + salary;
    }
}