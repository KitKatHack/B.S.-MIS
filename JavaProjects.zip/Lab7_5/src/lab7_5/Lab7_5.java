package lab7_5;

public class Lab7_5 {
	  public static void main(String[] args) {
	        Doctor doctor1 = new Doctor("Dr. Rodgers", 80000.0, "Pediatrician", 95.0);
	        Doctor doctor2 = new Doctor("Dr. James", 90000.0, "Obstetrician", 110.0);
	        Doctor doctor3 = new Doctor("Dr. Brandon", 110000.0, "Dermatologist", 130.0);
	        
	        
	        System.out.println("Doctor 1:\n" + doctor1);
	        System.out.println("\nDoctor 2:\n" + doctor2);
	        System.out.println("\nDoctor 3:\n" + doctor3);
	    }
	}