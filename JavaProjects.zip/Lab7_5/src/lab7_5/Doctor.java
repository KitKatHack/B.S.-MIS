package lab7_5;

class Doctor extends SalariedEmployee {
    private String specialty;
    private double officeVisitFee;

    public Doctor(String name, double salary, String specialty, double officeVisitFee) {
        super(name, salary);
        this.specialty = specialty;
        this.officeVisitFee = officeVisitFee;
    }

    public String getSpecialty() {
        return specialty;
    }

    public double getOfficeVisitFee() {
        return officeVisitFee;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public void setOfficeVisitFee(double officeVisitFee) {
        this.officeVisitFee = officeVisitFee;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Doctor)) {
            return false;
        }
        Doctor otherDoctor = (Doctor) obj;
        return super.equals(obj) && specialty.equals(otherDoctor.specialty) &&
               officeVisitFee == otherDoctor.officeVisitFee;
    }

    public String toString() {
        return super.toString() + "\nSpecialty: " + specialty + "\nOffice Visit Fee: " + officeVisitFee;
    }
}