package practice2_Exam1Pt1;

public class Practice2_Exam1Pt1 {
	public static void main (String[] args) {
		
		
		double Toby = 50391;
		double Andy = 60240;
		double Kevin = 90403;
		
		
		double Toby_hour = Toby/3600;
		double Andy_hour =  Andy/3600;
		double Kevin_hour = Kevin/3600;
	
		
		double Toby_min = (Toby % 3600)/60;
		double Andy_min =  (Andy % 3600)/60;
		double Kevin_min = (Kevin % 3600)/60;

		
		double Toby_sec = (Toby % 3600) % 60;
		double Andy_sec =  (Andy % 3600) % 60;
		double Kevin_sec = (Kevin % 3600) % 60;
		
		System.out.println("Toby ran the marathon in " + Toby_hour + " hours and " + Toby_min + " minutes and " + Toby_sec + " seconds.");
		System.out.println("Toby ran the marathon in " + Andy_hour + " hours and " + Andy_min + " minutes and " + Andy_sec + " seconds.");
		System.out.println("Toby ran the marathon in " + Kevin_hour + " hours and " + Kevin_min + " minutes and " + Kevin_sec + " seconds.");

	
	}
	
}
