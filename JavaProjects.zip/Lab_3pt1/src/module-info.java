/**
 * 
 */
/**
 * 
 */
module Lab_3pt1 {
}