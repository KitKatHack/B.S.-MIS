package lab_3pt1;
	import java.util.Scanner;
	import java.lang.Math;
	
public class Lab_3pt1 {
	public static void main (String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		
		double n = 64.0;
		double r;
		int guessCount = 1;
		double previousGuess;
			
		
		System.out.println("To guess the square root, enter a positive integer:");
		double guess = keyboard.nextDouble();
		System.out.println("Guess 1: " + guess);
		
	
		
	do {
		
		previousGuess = guess;
		r = n/previousGuess;
		guess = (previousGuess + r) / 2;
		guessCount++;
		System.out.printf("Guess " + guessCount + ": " + "%-6.4f \n", guess);
	} while(Math.abs(guess - previousGuess) / previousGuess >= 0.01);
		
	
	
	}
	
}