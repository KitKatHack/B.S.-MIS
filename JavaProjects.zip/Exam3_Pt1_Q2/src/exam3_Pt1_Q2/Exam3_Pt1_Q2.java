package exam3_Pt1_Q2;
public class Exam3_Pt1_Q2 {
	public static void main (String []args) {
		int [] field = {2, 20, 3, 45, 13, 16, 15, 45, 3, 3, 17, 9, 10, 1, 5, 8, 12, 92, 14, 9, 1, 4, 33, 37, 71};
        int totalElements = field.length;
        System.out.println("Total # of Elements: " + totalElements);

        
		 int oddElements = 0;
	        for (int num : field) {
	            if (num % 2 != 0) {
	                oddElements++;
	            }
	        }
	        
	        System.out.println("# of Odd Elements: " + oddElements);

	        int evenElements = totalElements - oddElements;
	        System.out.println("# of Even Elements: " + evenElements);

	        
	        int sum = 0;
	        for (int element : field) {
	            sum += element;
	        }
	        double average = (double) sum / totalElements;
	        System.out.println("Average of array elements: " + average);
	    }
}

