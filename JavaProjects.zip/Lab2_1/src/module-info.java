/**
 * 
 */
/**
 * 
 */
module Lab2_1 {
}