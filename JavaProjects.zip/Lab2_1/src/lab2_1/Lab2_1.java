package lab2_1;
import java.util.Scanner;

public class Lab2_1 {
	public static void main (String[] args) {

	
		double n = 64.0;
		
	
	Scanner keyboard = new Scanner(System.in);
	System.out.println("Enter a whole number to guess the square root of n");
	double guess = keyboard.nextDouble();
	
	
	double r= n/guess;
	guess = (guess +r)/2;
	System.out.print("Guess 2: ");
	System.out.println(guess);
	
	
	r=n/guess;
	guess = (guess + r)/2;
	System.out.print("Guess 3: ");
	System.out.println(guess);
	
	
	r= n/guess;
	guess = (guess + r)/2;
	System.out.print("Guess 4: ");
	System.out.println(guess);
	
	
	r= n/guess;
	guess = (guess + r)/2;
	System.out.print("Guess 5: ");
	System.out.println(guess);
	
	
	r= n/guess;
	guess = (guess + r)/2;
	System.out.print("Guess 6: ");
	System.out.printf("%2.2f",guess);
	
	
	
	}

}
