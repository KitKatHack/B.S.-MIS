package lab7_7;

class Patient extends Person {
    private Doctor primaryPhysician;

    public Patient(String name, Doctor primaryPhysician) {
        super(name);
        this.primaryPhysician = primaryPhysician;
    }

    public Doctor getPrimaryPhysician() {
        return primaryPhysician;
    }

}
