package lab7_7;

public class Lab7_7 {
	 public static void main(String[] args) {

		 	Doctor doctor1 = new Doctor("Dr. Charles", "Pediatrics");
	        Patient patient1 = new Patient("Harry Smith", doctor1);

	        System.out.println("Doctor: " + doctor1);
	        System.out.println("Patient: " + patient1);

	        Billing billing1 = new Billing(patient1, doctor1, 150.00);
	        System.out.println("Billing: " + billing1);
	        
	        
	        System.out.println("\n");
	        Doctor doctor2 = new Doctor("Dr. Harrold", " Neurology");
	        Patient patient2 = new Patient("Debra Randi", doctor2);
	        
	        System.out.println("Doctor: " + doctor2);
	        System.out.println("Patient: " + patient2);
	        
	        Billing billing2 = new Billing(patient2, doctor2, 220.00);
	        System.out.println("Billing: " + billing2);


	    }

}