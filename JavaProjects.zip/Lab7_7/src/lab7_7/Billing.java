package lab7_7;

class Billing {
    private Patient patient;
    private Doctor doctor;
    private double amountDue;

    public Billing(Patient patient, Doctor doctor, double amountDue) {
        this.patient = patient;
        this.doctor = doctor;
        this.amountDue = amountDue;
    }

    public double getAmountDue() {
        return amountDue;
    }

    public String toString() {
        return "$" + amountDue;
    }

}
