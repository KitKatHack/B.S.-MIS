package lab7_7;

class Doctor extends Person {
    private String specialization;

    public Doctor(String name, String specialization) {
        super(name);
        this.specialization = specialization;
    }

    public String getSpecialization() {
        return specialization;
    }

    public String toString() {
        return getName() + "\nSpecialization: " + specialization;
    }
}