package lab_3pt4;
	import java.util.Scanner;
	import java.lang.Math;
public class Lab_3pt4 {
	public static void main (String[] args) {
		Scanner keyboard = new Scanner(System.in);
	
		
		System.out.println ("Would you like to compute a new calculation?");
		String newProgram = keyboard.next().toLowerCase();	

		
		while(newProgram.equals("yes")) {
		System.out.println ("What is the cost of items?");
		 int cost = keyboard.nextInt();		

		
		System.out.println ("How many years from now?");
		 int years = keyboard.nextInt();		

		
		System.out.println ("What is the rate of inflation in %?");
		 double rate = keyboard.nextDouble();
		 
		 double interest = (1 + (rate/100));
		 
		 double power = Math.pow(interest, years);

			double futureCost = (cost*power);
		 
			System.out.printf ("Your future cost in " + years + " years is $ " + "%-6.2f\n", futureCost);
			
			
		}
		
		
	}
	}
