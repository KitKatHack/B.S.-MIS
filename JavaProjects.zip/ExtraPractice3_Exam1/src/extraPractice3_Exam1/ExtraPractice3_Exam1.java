package extraPractice3_Exam1;
import java.util.Scanner;

public class ExtraPractice3_Exam1 {
	public static void main (String [] args) {
		Scanner Keyboard = new Scanner (System.in);
		
		double balance = 500;
		
		
		 System.out.println ("Please input withdrawal amount:");
		 	double withdraw = Keyboard.nextDouble();
		
		 	
		 	double newbal = balance - withdraw;
		 	
	
		 	
		System.out.printf ("Your new balance total is " + "$%6.2f", newbal);
		System.out.println (" Your cash will be in denominations of 20's and the remainer in 10's.");


			double twenties = withdraw/20;
		System.out.println (" Your withdrawal will be processed in " + twenties + " $20 bills.");
			
			double tens = (withdraw % twenties)/10;
		System.out.println (" Your withdrawal will be processed in " + tens + " $10 bills.");

		
		
	}
	
	
}
