package lab2_3;
import java.util.Scanner;

public class Lab2_3 {
	public static void main (String[] args) 
	{
		Scanner scannerObject = new Scanner(System.in);
	
		int n1, n2;
	
		n1 = scannerObject.nextInt();
		n2 = scannerObject.nextInt();
		
		
		
		int sum = (n1 + n2);
		int difference = (n2 - n1); 
		int product = (n1 * n2);
	

		
		System.out.println("You entered " + n1 + " and " + n2 );
		System.out.println("The sum of " + n1 + " and " + n2 + " is " + sum);
		System.out.println("The difference of " + n1 + " and " + n2 + " is " + difference);
		System.out.println("The product of " + n1 + " and " + n2 + " is " + product);

	
	}

}
