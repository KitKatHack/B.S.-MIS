package lab6_1;
	import java.util.Scanner;
public class Lab6_1 {
	public static void main (String []args) {
		Scanner keyboard = new Scanner (System.in);
		
		double difficulty;
        do {
            System.out.print("Enter the degree of difficulty (1.2 to 3.8): ");
            difficulty = keyboard.nextDouble();
        } 
        	while (difficulty < 1.2 || difficulty > 3.8);

        
        double[] scores = new double[7];
        for (int i = 0; i < 7; i++) {
            do {
                System.out.print("Judge " + (i + 1) + "'s Score (0 to 10): ");
                scores[i] = keyboard.nextDouble();
            } while (scores[i] < 0 || scores[i] > 10);
        }

        double overallScore = calculateOverallScore(difficulty, scores);

        System.out.println("Overall score: " + overallScore);

        keyboard.close();
    }

    private static double calculateOverallScore(double difficulty, double[] divingScores) {
        double minScore = divingScores[0];
        double maxScore = divingScores[0];
        double totalScore = divingScores[0];

        for (int i = 1; i < divingScores.length; i++) {
            totalScore += divingScores[i];

            if (divingScores[i] < minScore) {
                minScore = divingScores[i];
            }

            if (divingScores[i] > maxScore) {
                maxScore = divingScores[i];
            }
        }

        totalScore = totalScore - minScore - maxScore;

        totalScore *= difficulty;

        return totalScore * 0.6;
    }
}
		
		
		
		
		/*
		float[] divingScores = new float[7];
		float max = divingScores[0];
		float min = divingScores[0];
		
		System.out.println("Judges please enter score here (0-10): ");
		
		for(int i = 0; i < divingScores.length;i++) {
			
			if (keyboard.nextFloat() >= 1 && keyboard.nextFloat()<=10){
			
				 if (divingScores[i] > max) {
					max = divingScores[i];
				 }
					 if (divingScores[i] < min) {
						min = divingScores[i];
					}
			}
		
			else {
				System.out.println("Please enter a value (0-10):");
				break;
			
				/*for(max = 1; max < divingScores.length max++) {*/					
					
		/*
			}
		}
		
		System.out.println("Score 1:" + divingScores[1]);
		System.out.println("Score 2:" + divingScores[2]); 
		System.out.println("Score 3:" + divingScores[3]); 
		System.out.println("Score 4:" + divingScores[4]); 
		System.out.println("Score 5:" + divingScores[5]); 
		System.out.println("Score min:" + min); 
		System.out.println("Score max:" + max); 
	}
}

/*score between 0 and 10, highest and lowest scores are thrown out, 
 * remaining scores are added together,
 * sum is multiplied by  degree of difficulty for that dive
 * difficulty ranges from 1.2 to 3.8 points
 * 
 *  program that inputs a degree of difficulty, seven judges’ scores
 *  outputs  overall score for that dive.
 */
