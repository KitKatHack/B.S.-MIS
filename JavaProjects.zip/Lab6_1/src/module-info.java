/**
 * 
 */
/**
 * 
 */
module Lab6_1 {
}