package lab7_3;

public class Lab7_3 {
    public static void main(String[] args) {

    	AlienPack alienPack = new AlienPack(3);
        alienPack.addAlien(new SnakeAlien(100, "Snake Alien"), 0);
        alienPack.addAlien(new OgreAlien(100, "Ogre Alien"), 1);
        alienPack.addAlien(new MarshmallowManAlien(100, "Marshmallow Man Alien"), 2);

        System.out.println("Total damage: " + alienPack.calculateDamage());
    }

}
