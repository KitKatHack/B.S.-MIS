package lab7_3;

abstract class Alien {
    private int health;
    private String name;

    public Alien(int health, String name) {
        this.health = health;
        this.name = name;
    }

    public abstract int getDamage();

    public int getHealth() {
        return health;
    }

    public String getName() {
        return name;
    }
}
