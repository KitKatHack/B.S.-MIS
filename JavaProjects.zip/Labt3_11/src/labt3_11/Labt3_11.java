package labt3_11;
	import java.util.ArrayList;
	import java.util.List;
	import java.util.Random;
public class Labt3_11 {
	public static void main (String[] args) {
	Random randomGenerator = new Random ();	
	
	
		int finalist = 30;
		int winners = 3;
		
		List<Integer> list = new ArrayList(finalist);
		for (int i = 1; i <= finalist; i++) {
			System.out.println ("Finalist " + i);
			}

		
		List<Integer> winnerList = new ArrayList(winners);
		System.out.println("The winners are : \n");
		for (int n = 1; n <= winners;n++) {
			
			int randomWinners = randomGenerator.nextInt(finalist);
			System.out.println(randomWinners);

				if (list.contains(randomWinners)) {
					list.remove(randomWinners);
			 
			

			}
			}}
	}
	
		
		
		
		/*
			while	(winners <= finalist) {
			int randomWinner1 = randomGenerator.nextInt(finalist);
			int randomWinner2 = randomGenerator.nextInt(finalist);
			int randomWinner3 = randomGenerator.nextInt(finalist);

		List<Integer> list = new ArrayList();
		for (int i = 1; i <= finalist; i++) {
			System.out.println ("Finalist " + i);
			}

		
		List<Integer> winnerList = new ArrayList();
		
		for (int n = 1; n <= winners; n++) {	
			int randomWinners = randomGenerator.nextInt(finalist);
		
			winnerList.add(randomWinners);
			finalist.remove(index);

			if (list.contains(finalist)) {
				list.remove(finalist);
				
			
		}
		System.out.println (randomWinners);
		}
			
		/*				List<Integer> list = new ArrayList();
					list.add(i)
			if (!list.contains(pickFinal)) {
				list.add(pickFinal);
				pickFinal.remove(list);

			}
			
			else {
				System.out.println ("Winner " + pickFinal);
			}
			
			/*
			if (!pickFinal.contains(finalist)){
				pickFinal.add(pickFinal);

			}
			
			
			/*boolean alreadyPicked []= new boolean[pickFinal];
			 alreadyPicked [n] = false;
			 	if (alreadyPicked[pickFinal] == false);
			 		System.out.println("Winners " + alreadyPicked[n]);
			 
		*/
			
	
	
	
