package labt3_10;
	import java.util.Random;
	import java.util.Scanner;
public class Labt3_10 {
	public static void main (String[] args) {
		Scanner keyboard = new Scanner(System.in);
		Random randomGenerator = new Random ();
		
		int humanPoint = 0;
		int compPoint = 0;
		
		System.out.println("Human player goes first.\n ");
		
		
		
		while (humanPoint < 100 && compPoint < 100) {
			System.out.println("Human's turn - please input 'r' to roll again or 'h' to hold:");
			String input = keyboard.nextLine().toLowerCase();

			
			
		}
		
	}}
		
		
		
/*
 * 
 * or new roll>1 && new roll 7
 * after printing 1, do else only since every other roll is 2-7
 * 
 * 
 * 
		for (int i = 0; i < 100; i++) {
			int humanRoll = randomGenerator.nextInt(1,7);
			int compRoll = randomGenerator.nextInt(1,7);
			System.out.println(i++);
			
		if ( humanRoll >= 1) {
			compRoll = randomGenerator.nextInt(1,7);
			}
			
		else if (humanRoll == 2 || humanRoll == 3 || humanRoll == 4|| humanRoll == 5 || humanRoll == 6) {
			humanPoint++;	
			System.out.println ("1 point earned. Would you like to 'Roll again' or 'Hold'.");
			String input = keyboard.nextLine().toLowerCase();
			}
			
			
		*/
		
		/*
		for (int n = 0; n < 100; n++) {
			compRoll = randomGenerator.nextInt(1,7);
			System.out.println(n++);
			
		}
		while ( compRoll >= 1) {
			humanRoll = randomGenerator.nextInt(1,7);	
		}
		
	while (compRoll == 2 || compRoll == 3 || compRoll == 4|| compRoll == 5 || compRoll == 6) {
		compPoint++;	
		System.out.println ("1 point earned. Would you like to 'Roll again' or 'Hold'.");
		String input = keyboard.nextLine().toLowerCase();
		
		if (input == "roll again") {
			compRoll = randomGenerator.nextInt(1,7);
		}
			else {
				humanRoll = randomGenerator.nextInt(1,7);
	
			}
			
	
	
		System.out.println ("Your score is " + humanPoint + "Computer's score is " + compPoint);	
*/
			/*
			for (int n = 0; n < 100; n++) {
				int rollHuman = randomGenerator.nextInt(1,7);
				System.out.println(n++);
				
				
		if (rollHuman >= 1) {
			humanPoint = 0;
			System.out.println ("You have rolled " + n++ + " times.");
			System.out.println ("Your current score is " + humanPoint);
			System.out.println ("The other player's score is " + compPoint++);
			System.out.println ("No points earned. Next player's turn.");
			i++;
}
		
		else if (rollHuman == 2 || rollHuman == 3 || rollHuman == 4|| rollHuman == 5 || rollHuman == 6) {
			humanPoint = 1;		
			System.out.println ("You have rolled " + n++ + " times.");
			System.out.println ("Your current score is " + humanPoint);
			System.out.println ("The other player's score is " + compPoint++);
			System.out.println ("1 point earned. Would you like to 'Roll again' or 'Hold'.");
			String input = keyboard.nextLine().toLowerCase();
			n++;*/
		

/*
if (roll_comp == 1) {
	system.out.println (i);
	system.out.println ("No points earned. Next turn.");
	i++;	
}
 else if (roll_comp == 2 || roll == 3 || roll == 4|| roll == 5 || roll == 6)
	system.out.println ("1 points earned. Keep rolling.");
	i++;	

else {
	*/

	
	

		
		
