package lab4_7;

public class Temperature {
	
	
	private double temperature;
	private char scale;
	
	
	public Temperature() {
		this.temperature = 0.0;
		this.scale = 'C';
	}
	public Temperature(double temperature) {
		this.temperature = temperature;
		this.scale = 'C';
	}
	public Temperature (char scale) {
		this.temperature = 0.0;
		this.scale = scale;
	}
	public Temperature(double temperature, char scale) {
		this.temperature = temperature;
		this.scale = scale;
	}
	public double celsius() {
		if(scale == 'C') {
			return (5.0 * (this.temperature - 32.0))/9;
		}
		return this.temperature;
	}
	public double fahrenheit() {
		if(scale == 'F') {
			return (9.0 * (this.temperature/5) + 32.0);
		}
			return this.scale;
		}
	
	
	
	public void setTemp(double temperature){
		this.temperature = temperature;
	}
	public void setScale(char scale) {
		if (scale == 'C' || scale == 'F') {
			this.scale = scale;
	}
	}
	public void setTempScale(double temperature, char scale) {
		setTemp(temperature);
		setScale(scale);
	}
	
	
	public boolean equals(Temperature other) {
		return this.celsius() == other.celsius();
	}
	public boolean greaterThan(Temperature other) {
		return this.celsius() > other.celsius();
	}
	public boolean lessThan(Temperature other) {
		return this.celsius() < other.celsius();
	}	
	
	
	
	public String toString() {
		return this.temperature + " degrees " + this.scale;
	}
}
