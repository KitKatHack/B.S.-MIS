package lab4_7;

public class Lab4_7 {
	public static void main(String []args) {
		
		Temperature temp1 = new Temperature();
		Temperature temp2 = new Temperature(32.0,'F');
		Temperature temp3 = new Temperature(-40.0,'C');
		Temperature temp4 = new Temperature(-40.0,'F');
		Temperature temp5 = new Temperature(100.0,'C');
		Temperature temp6 = new Temperature(212.0,'F');

		
		
		System.out.println("\nTemp 1 is " + temp1);
		System.out.println("Temp 2 is " + temp2);
		System.out.println("Temp 3 is " + temp3);
		System.out.println("Temp 4 is " + temp4);
		System.out.println("Temp 5 is " + temp5);
		System.out.println("Temp 6 is " + temp6);

		System.out.println("\nTemp 1 = Temp 2 " + temp1.equals(temp2));
		System.out.println("Temp 3 = Temp 4 " + temp3.equals(temp4));
		System.out.println("Temp 5 = Temp 6 " + temp5.equals(temp6));
		
		
		System.out.println("\nTemp 1 > Temp 3 " + temp1.greaterThan(temp3));
		System.out.println("Temp 4 > Temp 6 " + temp4.greaterThan(temp6));
		
		System.out.println("\nemp 1 < Temp 5 " + temp1.lessThan(temp5));
		System.out.println("Temp 2 < Temp 4 " + temp2.lessThan(temp4));	
		
	}
}
