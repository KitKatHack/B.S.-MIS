package exam1_Pt2_Q1;
	import java.util.Scanner;
	
public class Exam1_Pt2_Q1 {
	public static void main (String [] args) {
		Scanner Keyboard = new Scanner(System.in);
	
	System.out.println ("Please enter price of vending machine item (from 25 cents to a $1, 5-cent increments) :");
	
	int price = Keyboard.nextInt();
	
	int change = 100 - price;
	
		double quarters = (change/25);
		change%=25;
		double dimes = (change/10);
		change%=10;
		double nickels = (change/5);
		change%=5;
		
		
	
		System.out.printf("You paid with $1 and entered an item priced at $." + price + " your change is $." + (100-price));
		System.out.println();
		
		System.out.printf("Your change in quarters is " + "%2.0f", quarters);
		System.out.println();

		System.out.printf("Your change in dimes is " + "%2.0f", dimes);
		System.out.println();
		
		System.out.printf("Your change in nickels is " + "%2.0f", nickels);
		System.out.println();
	
	}
}