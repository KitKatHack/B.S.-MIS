package lab_3pt3;
	import java.util.Scanner;
public class Lab_3pt3 {
	public static void main (String[] args) {
		Scanner keyboard = new Scanner(System.in);

		
		System.out.println ("Would you like to compute a new calculation?");
		String newProgram = keyboard.next().toLowerCase();	

		
		while(newProgram.equals("yes")) {
		System.out.println ("Is child male or female?");
		 String gender = keyboard.next().toLowerCase();		
		 
		System.out.println ("What is height of mother in inches?");
		int heightMother = keyboard.nextInt();
		
		System.out.println ("What is height of father in inches?");
		int heightFather = keyboard.nextInt();
		
		int childFemale = ((heightFather*(12/13) + heightMother)/2);
		int childMale = ((heightMother*(13/12) + heightFather)/2);
		
		
		do {
			System.out.println ("Child height is " + childFemale + " inches tall.");
		}	while (gender == "female");
			
		do {
			System.out.println ("Child height is " + childMale + " inches tall.\n");
		}	while (gender == "male");
			
		
		
		}
	}
}
	
	

