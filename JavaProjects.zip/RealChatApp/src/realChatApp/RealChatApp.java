package realChatApp;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class RealChatApp {
	public static void main (String [] args) {
		
		Scanner chat = new Scanner(System.in);

		 Map<String, Integer> trackingMap = new HashMap<>();
	        trackingMap.put("novilla mattress", 1044);
	        trackingMap.put("tineco floor one s5 vacuum", 8375);
	        trackingMap.put("gourmia 7-qrt digital air fryer", 4867);

	        Map<Integer, String> productNameMap = new HashMap<>();
	        productNameMap.put(1044, "novilla mattress");
	        productNameMap.put(8375, "tineco floor one s5 vacuum");
	        productNameMap.put(4867, "gourmia 7-qrt digital air fryer");

	        Map<String, Double> priceMap = new HashMap<>();
	        priceMap.put("novilla mattress", 499.99);
	        priceMap.put("tineco floor one s5 vacuum", 299.99);
	        priceMap.put("gourmia 7-qrt digital air fryer", 149.99);
 
	        System.out.println("Recent Product Orders:");
	        for (String product : trackingMap.keySet()) {
	            System.out.println("- " + product + " (Product Number: " + trackingMap.get(product) + ")");
	        }

	        System.out.println("\nHello, Welcome to RealChat, how can I assist you today?");

	        do {
	            System.out.println("Enter the product number you want to chat about. Type 'exit' to end the conversation.");
	            String input = chat.next().toLowerCase();

	            if (input.equals("exit")) {
	                System.out.println("Thank you for using RealChat. Goodbye!");
	                break;
	            }

	            if (isNumeric(input)) {
	                int productNumber = Integer.parseInt(input);
	                if (productNameMap.containsKey(productNumber)) {
	                    processProduct(chat, productNameMap.get(productNumber), trackingMap, priceMap);
	                } else {
	                    System.out.println("Invalid product number. Please enter a valid product number or name.");
	                }
	            } else {
	                processProduct(chat, input, trackingMap, priceMap);
	            }

	            System.out.println("Do you want to chat about another product? Enter 'yes' to continue or 'exit' to end the conversation.");
	        } while (chat.next().equalsIgnoreCase("yes"));
	    }

	    private static void processProduct(Scanner chat, String productName, Map<String, Integer> trackingMap, Map<String, Double> priceMap) {
	        if (trackingMap.containsKey(productName) && priceMap.containsKey(productName)) {
	            int trackingNumber = trackingMap.get(productName);
	            double price = priceMap.get(productName);

	            System.out.println(productName + " Tracking #: " + trackingNumber);
	            System.out.println("Product Price: $" + price);

	            System.out.println("What would you like to do?");
	            System.out.println("1. Track Order");
	            System.out.println("2. Request Refund");
	            System.out.println("3. Speak to a Representative");
	            int choice = chat.nextInt();

	            switch (choice) {
	                case 1:
	                    System.out.println("Your order is on its way. UPS tracking code will be sent to phone ending in #4653.");
	                    break;
	                case 2:
	                    System.out.println("You've requested a refund for $" + price);
	                    double refund = calcRefund(price);
	                    System.out.println("Refund amount after deducting California sales tax (7.25%): $" + formatDecimal(refund));
	                    System.out.println("Refund will be processed by tonight to the original payment method.");
	                    break;
	                case 3:
	                    System.out.println("Please wait for a representative to call you. Approximate wait time is 5 minutes.");
	                    System.out.println("Thank you for your patience.");
	                    break;
	                default:
	                    System.out.println("Invalid selection. Please enter valid selection.");
	            }
	        } else {
	            System.out.println("Sorry, I couldn't recognize the product. Please enter valid product number.");
	        }
	    }

	    private static boolean isNumeric(String str) {
	        try {
	            Integer.parseInt(str);
	            return true;
	        } catch (NumberFormatException e) {
	            return false;
	        }
	    }
	    private static double calcRefund(double originalPrice) {
	        // California sales tax is 7.25%
	        double salesTaxRate = 0.0725;
	        return originalPrice - (originalPrice * salesTaxRate);
	    }
	    private static String formatDecimal(double value) {
	        DecimalFormat decimalFormat = new DecimalFormat("#.##");
	        return decimalFormat.format(value);
	    }
	}
		
		
		
		  
		/* int track = 394955342;
	        int returnNo = 99787819;
	        double price = 499.99;

	        // Initial list of recent product orders
	 
	        System.out.println("\nHello, Welcome to RealChat, how can I assist you today?");

	        do {
	            System.out.println("Based on your recent purchases, what product are you chatting about? Please enter listing # or 'exit' to end the conversation.");
	            System.out.println("Purchases within the last 3 months:");
		        System.out.println("1. 10in. Novilla Mattress");
		        System.out.println("2. Tineco Floor One S5 Vacuum");
		        System.out.println("3. Gourmia 7-Qrt Digital Air Fryer");
		        System.out.println("4. JBL Flip 5 Portable Speaker");
		        System.out.println("5. Bose Quiet Comfort Headphones");
		        
		        
		        System.out.println("6. Different Puchase");

	            String productName = chat.next().toLowerCase();


	            if (productName.equals("exit")) {
	                System.out.println("Thank you for using RealChat. Goodbye!");
	                break;
	            }

	            processProduct(chat, productName, track, returnNo, price);

	            System.out.println("Do you want to chat about another product? Enter 'yes' to continue or 'exit' to end the conversation.");
	        } while (chat.next().equalsIgnoreCase("yes"));
	    }

	    private static void processProduct(Scanner chat, String productName, int track, int returnNo, double price) {
	        switch (productName) {
	            case "1":
	                System.out.println("10in. Novilla Mattress Tracking #: " + track);
	                System.out.println("Estimated Delivery Date: 11-04-23, 1pm-4pm pst.");
	                break;
	            case "2":
	                System.out.println("Is your Tineco Floor One S5 Vacuum within the 30-day return period? Please indicate 'yes' or 'no'.");
	                String returnInput = chat.next().toLowerCase();
	                if (returnInput.equals("yes")) {
	                    System.out.println("Tineco Floor One S5 Vacuum Return #: " + returnNo);
	                    double refund = price - (price * 0.0725);
	                    System.out.println("$" + refund + " will be refunded by tonight to card #5588, not including sales tax.");
	                } else {
	                    System.out.println("Thank you for using RealChat. Goodbye!");
	                }
	                break;
	            case "3":
	                System.out.println("What concern do you have regarding your Gourmia 7-Qrt Digital Air Fryer?");
	                // Add more specific actions for this product if needed
	                break;
	            case "4":
	                System.out.println("What can I help you with regarding your JBL Flip 5 Portable Speaker?");
	                // Add more specific actions for this product if needed
	                break;
	            case "5":
	                System.out.println("What can I help you with regarding your Bose Quiet Comfort Headphones?");
	                // Add more specific actions for this product if needed
	                break;
	            case "6":
	                System.out.println("You mentioned a new product. How can I assist you with it?");
	                // Add specific actions for the new product
	                break;
	            default:
	                System.out.println("Sorry, I couldn't recognize the product. Please enter the full product name.");
	        }
	    }
	}*/
		
		        
		        
		
		
		/*int track = 394955342;
	        int returnNo = 99787819;
	        double price = 499.99;

	        System.out.println("Hello, Welcome to RealChat, how can I assist you today?");

	        System.out.println("Based on your recent purchases, are you chatting about your 10in. Novilla Mattress? Please indicate 'Yes' or 'No'");
	        String input = chat.next().toLowerCase();

	        switch (input) {
	            case "yes":
	                System.out.println("10in. Novilla Mattress Tracking #: " + track);
	                System.out.println("Estimated Delivery Date: 11-04-23, 1pm-4pm pst.");
	                break;
	            case "no":
	                System.out.println("Perhaps your Tineco Floor One S5 Vacuum? Please indicate 'Yes' or 'No'.");
	                String vacuumInput = chat.next().toLowerCase();
	                switch (vacuumInput) {
	                    case "yes":
	                        System.out.println("Your Tineco Floor One S5 Vacuum is within the 30-day return period. Would you like to return the item? Please indicate 'Yes' or 'No'.");
	                        String returnInput = chat.next().toLowerCase();
	                        switch (returnInput) {
	                            case "yes":
	                                System.out.println("Tineco Floor One S5 Vacuum Return #: " + returnNo);
	                                double refund = price - (price * 0.0725);
	                                System.out.println("$" + refund + " will be refunded by tonight to card #5588, not including sales tax.");
	                                break;
	                        }
	                        break;
	                    case "no":
	                        System.out.println("No more orders in the last 3 months. Would you like to speak to a representative. Please indicate 'yes' or 'no'.");
	                        String human = chat.next().toLowerCase().toLowerCase();
	                        if (human.equals("yes")) {
	                        	System.out.println("Please wait for representative to call you. Approx. wait time is 5 minutes.");
	                        	System.out.println("Thank you. Good bye.");
	                        } 
	                        	 else {
	 	                        	System.out.println("Thank you. Good bye.");
	                        	}
	                        }
	                }
	                }
	    }*/
	
		
		
		
		/*
        int track = 394955342;
        int returnNo = 99787819;
        double price = 499.99;

        System.out.println("Hello, Welcome to RealChat, how can I assist you today?");

        System.out.println("Based on your recent purchases, are you chatting about your 10in. Novilla Mattress? Please indicate 'Yes' or 'No'");
        String input = chat.next().toLowerCase();

        if (input.equals("yes")) {
            System.out.println("10in. Novilla Mattress Tracking #: " + track);
            System.out.println("Estimated Delivery Date: 11-04-23, 1pm-4pm pst.");
        } else if (input.equals("no")) {
            System.out.println("Perhaps your Tineco Floor One S5 Vacuum? Please indicate 'Yes' or 'No'");
            String vacuumInput = chat.next().toLowerCase();

            if (vacuumInput.equals("yes")) {
                System.out.println("Your Tineco Floor One S5 Vacuum is within the 30-day return period. Would you like to return the item? Please indicate 'Yes' or 'No'");
                String returnInput = chat.next().toLowerCase();

                if (returnInput.equals("yes")) {
                    System.out.println("Tineco Floor One S5 Vacuum Return #: " + returnNo);
                    double refund = price - (price * 0.0725);
                    System.out.println("Refund not including sales tax: " + refund);
                }
            } else if (vacuumInput.equals("no")) {
                System.out.println("Your orders within the last 6 months include Gourmia '7-Qrt Digital Air Fryer', 'JBL Flip 5 Portable Speaker', and 'Bose Quiet Comfort Headphones'. \nPlease indicate which one you would like to chat about by it's full name.");
            }
        }
    }
}*/
		
		
		
		
		
		
