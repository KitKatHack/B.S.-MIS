package lab4_1;

public class Lab4_1 {
	public static void main (String[]args) {
	
		BeerSong ourVariable = new BeerSong();
		
		
		ourVariable.beersOnTheWall(100);
		ourVariable.printSong(100);

		
		
	}
	
}


/* 		
 * 
 * class named BeerSong 
 * BeerSong whose constructor takes an integer parameter that is the number of bottles of beer initially on the wall.
 * If parameter is less than zero, set number of bottles to zero.
 * if parameter is greater than 99, set number of beer bottles to 99.
 * Then make a public method called printSong that outputs all stanzas from the number of bottles of beer down to zero. 
 * */

