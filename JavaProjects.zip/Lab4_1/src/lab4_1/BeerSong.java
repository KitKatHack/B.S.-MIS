package lab4_1;

public class BeerSong {	
		
	/*cannot have two main methods in Lab4.1 and BeersSong */
		
	int numberOfBeers;
		
	
	
		public int beersOnTheWall(int numberOfBeers) {
			
			
		if (numberOfBeers < 0) {
			 this.numberOfBeers = 0;
			 return this.numberOfBeers;
		}
		else if (numberOfBeers > 99) {
			 this.numberOfBeers = 99;
			 return this.numberOfBeers;
		}
		else {
			return this.numberOfBeers;
		}
		}
			
	
		
		public int printSong (int NumberOfBeers) {
			beersOnTheWall(this.numberOfBeers);
			while (this.numberOfBeers >= 0) {
				System.out.println(this.numberOfBeers + " beers on the wall.");
				this.numberOfBeers --;
	
			}
			
			return this.numberOfBeers;
		}
	}





/*		class named BeerSong 
 * BeerSong whose constructor takes an integer parameter that is the number of bottles of beer initially on the wall.
 * If parameter is less than zero, set number of bottles to zero.
 * if parameter is greater than 99, set number of beer bottles to 99.
 * Then make a public method called printSong that outputs all stanzas from the number of bottles of beer down to zero. 
 * */
