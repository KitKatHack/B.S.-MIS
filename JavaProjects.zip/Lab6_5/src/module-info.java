/**
 * 
 */
/**
 * 
 */
module Lab6_5 {
}