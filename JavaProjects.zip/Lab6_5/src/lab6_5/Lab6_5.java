package lab6_5;
import java.lang.Math;
public class Lab6_5 {
	public static void main(String[]args) {
		
		
		double[] array = {4.4, 6.1, 6.9, 7.3, 9.9, 9.4, 5.0, 8.7};
        int used = 6;
        double output = calc(array, used);
        System.out.println("Standard Deviation: " + output);
    }

	
    public static double calc(double[] array, int used) {
        if (used <= 1) {
            return 0.0;
        }
        

        double sum = 0;
        for (int i = 0; i < used; i++) {
            sum += array[i];
        }
        
        double average = sum / used;
        double squared = 0;
        for (int i = 0; i < used; i++) {
            squared += Math.pow(array[i] - average, 2);
        }

        
        double variance = squared / used;
        return Math.sqrt(variance);
    }
}
		
		
		
		
		
		//public static final int standardDev = 10;
		//(n1 - a)2, (n2 - a)2, (n3 - a)2, and so forth.
		
/*
		int number = 0;
		double sum = 0;
		double[] calc = new double[10];
		 for (int i = 0; i < calc.length; i++) {
			 sum += calc[i];
			 System.out.println(sum);
				
				
				

		 }}}*/
/*
		
		int number = 8;
		double sum = 0.0;
		
		 double array [] = new double [5];
		 array [0] = 2.0;
		 array [1] = 5.5;
		 array [2] = 3.2;
		 array [3] = 1.4;
		 array [4] = 2.2;
			for (int i = 0; i < number; i++) {
				sum += array[i];
			}
		
			 double average = sum/number;
			 
			 double squared = 0.0;
			 for (int i = 0; i < number; i++) {
				 squared += Math.pow(array[i] - average, 2);
			 }
			 System.out.println(Math.sqrt(squared/number));	 
	
	
	
		//System.out.println(squared);//

	}


}
		
		
		
		/*double [] collection = {1.0,4.0,5.0,6.0,3.0,7,0};
		int number = 8;
		double stdev = calc(collection, number);

	
	
		System.out.println("Standard Deviation: " + calc);*/

		/*
		int [] array = new int[10];
		int a;
		
		for(int n = 0; n < array.length; n++) {
			array[n] = n+1;
			System.out.println("n * " + array[n]);
			
	//		 a = (array[n]/a)*n;
		
			double [] formula = new double[10];
			
			
			
		}
		
		//int deviation;
		
		//public static double standardDev (double[]array, int deviation) {
			//for(int i = 0; i < array.length; i++) {
			//	i++;
		//		System.out.println("Array: " + array.length);
				
			}
		
		
		
	
	}
		*/
		
	
		/*deviation = standardDev(array, deviation);
		

public static double standardDev (double[]array, int deviation) {
	for(int i = 0; i < deviation; i++) {
		i++;
		
		
	}
	}
		//newArray = ((b*1)-a)*2

	//	double number = array[i];
		


	
}
}*/
/*public static int deleteRepeats(char[] array, int size) {
	for (int i =0; i < size; i++) {
		char e = array [i];
		for(int b = i + 1; b < size; b++) {
			if (array[b] == e) {
				for(int c = b; c < size - 1; c++) {
					array[c] = array [c+1];
				}
				size --;
				b--;
			}
		}
	}

	return size;*/

		

