package lab4_6;

public class StudentRecord {

		private int quiz1;
		private int quiz2;
		private int quiz3;
		private int midterm;
		private int finalExam;
		private double overallScore;
		private String finalLetter;

		public StudentRecord(int quiz1, int quiz2, int quiz3, int midterm, int finalExam) {
			this.quiz1 = quiz1;
			this.quiz2 = quiz2;
			this.quiz3 = quiz3;
			this.midterm = midterm;
			this.finalExam = finalExam;
			calcOverall();
			calcFinalLetter();
		}
	
		public void calcOverall() {
			double quizPercent = ((quiz1+quiz2+quiz3) / 30) * 100;
			overallScore = (quizPercent*.25) + (midterm * .35) + (finalExam*.40);
			
		}
		
		public void calcFinalLetter() {
			if (overallScore >= 90.0) {
				finalLetter = "A";
			}
			else if (overallScore  >= 80.0) {
				finalLetter = "B";
			}
			else if (overallScore  >= 70.0) {
					finalLetter = "C";
			}
			else if (overallScore  >= 60.0) {
						finalLetter = "D";
			}
			else { finalLetter = "F";
			}
		}
			
		

	public String toString() {
		return "\nQuiz 1: " + quiz1
		+  "\nQuiz 2: " + quiz2
		+ "\nQuiz 3: " + quiz3
		+ "\nMidterm: " + midterm
		+  "\nFinal: " + finalExam
		+ "\nOverall Score: " + overallScore
		+ "\nFinal Grade: " + finalLetter;
	}
	}
	