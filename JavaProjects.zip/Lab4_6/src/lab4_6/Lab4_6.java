package lab4_6;
	import java.util.Scanner;
public class Lab4_6 {
	public static void main (String[] args) {
		Scanner scanner = new Scanner (System.in);
		
		
		System.out.println("Please enter 3 quiz scores (out of 10): ");
		int quiz1 = scanner.nextInt();
		int quiz2 = scanner.nextInt();
		int quiz3 = scanner.nextInt();

		System.out.println("Please enter midterm exam score (out of 100) : ");
		int midterm = scanner.nextInt();
		
		System.out.println("Please enter final exam score (out of 100) : ");
		int finalExam = scanner.nextInt();
		
		StudentRecord studentRec = new StudentRecord (quiz1,quiz2,quiz3,midterm,finalExam);
	
		System.out.println("Student Record: ");
		System.out.println(studentRec.toString());
		
		

		
	}
}
