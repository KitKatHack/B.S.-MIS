package lab7_1;
public class Payment {

	public Payment(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	
	
	
	double paymentAmount;
	
	
	
	public double getpaymentAmount () {
		return paymentAmount;
	}
	
	public void setpaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	
	public void /*String*/ paymentDetails () {
		System.out.println(paymentAmount);
		String paymentDetails = "Payment amount is " + paymentAmount;
		
		//return paymentDetails;
	}
	
	
	
	
	
	
}
