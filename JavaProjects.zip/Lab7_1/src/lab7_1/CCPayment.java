package lab7_1;
	public class CCPayment extends Payment{
		
		

		
		String nameOnCard;
		int expirationDate;
		String ccNumber;
		
		
	public CCPayment(double paymentAmount, String nameOnCard, int expirationDate, String ccNumber) {
			super (paymentAmount);
			this.nameOnCard = nameOnCard;
			this.expirationDate = expirationDate;
			this.ccNumber = ccNumber;
		}
		
	
	public void paymentDetails() {
		System.out.println("Payment amount in credit is $ " + paymentAmount + 
				"\nCard Holder: " + nameOnCard + 
				"\nExpiration Date: " + expirationDate + 
				"\nCredit Card Number: " + ccNumber);
	
	
	
	}
	}

