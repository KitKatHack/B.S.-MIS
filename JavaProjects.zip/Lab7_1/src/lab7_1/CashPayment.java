package lab7_1;

public class CashPayment extends Payment {

		
		public CashPayment(double paymentAmount) {
			super (paymentAmount);
		}
		
		
		public void paymentDetails() {
			System.out.println("Payment amount is $ " + paymentAmount);
		}
		
		
		
		
	}

