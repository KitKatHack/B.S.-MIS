package lab7_1;
public class Lab7_1 {
	public static void main (String []args) {
		
		CashPayment test1 = new CashPayment(50);
		CashPayment test2 = new CashPayment(100);
		
		CCPayment test3 = new CCPayment(30, "Nick Giacalone", 1123, "1234123456785678");
		CCPayment test4 = new CCPayment(90, "Lenny Brokhman", 0224, "5678567812341234");

		test1.paymentDetails();
		test2.paymentDetails();
		test3.paymentDetails();
		test4.paymentDetails();


		
	}
}
