package lab1_3;

public class Lab1_3 {
	public static void main (String[] args) {
	
		
	String first = "walt";
	String last = "savitch";
	
	System.out.println(first + " " + last);
	
	
	String firstUppercase = first.substring(0,1).toUpperCase() + first.substring(1, 4);
	String lastUppercase = last.substring(0,1).toUpperCase() + last.substring(1, 7);
		
	System.out.println (firstUppercase + " " + lastUppercase);
		
	
	String pigFirst = firstUppercase.substring(1,4) + firstUppercase.substring(0,1) + "ay";
	String pigLast = lastUppercase.substring(1,7) + lastUppercase.substring(0,1) + "ay";
	
	System.out.println(pigFirst);
	System.out.println(pigLast);

	
	System.out.println(pigFirst + " " + pigLast);
		
	
	

/*Write a program that starts with the string variable first set to your first name and the 
 * string variable last set to your last name. Both names should be all lowercase. Your program should 
 * then create a new string that contains your full name in pig latin with the first letter capitalized 
 * for the first and last name. Use only the pig latin rule of moving the first letter to the end of 
 * the word and adding “ay.” Output the pig latin name to the screen. Use the substring and toUpperCase 
 * methods to construct the new name. For example, given:
 * first = "walt"
 * last = "savitch"
 * The program should create a new string with the text “Altway Avitchsay” and print it.*/
	
	
	}

}
