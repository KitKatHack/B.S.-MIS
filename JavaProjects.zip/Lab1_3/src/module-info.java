/**
 * 
 */
/**
 * 
 */
module Lab1_3 {
}