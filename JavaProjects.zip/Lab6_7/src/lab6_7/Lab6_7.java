package lab6_7;
	import java.util.Scanner;
public class Lab6_7 {
	public static void main (String[] args) {
		
		 Scanner digit = new Scanner(System.in);

		 final int output = 20;
	      
	
	 do {
	            System.out.print("Please input 1st integer: ");
	            String digit1 = digit.next();
	            System.out.print("Please input 2nd positive integer: ");
	            String digit2 = digit.next();
	           
	            if (digit1.length() > output || digit2.length() > output) {
	                System.out.println("Error: Input integers exceed maximum length.");
	            }
	            
	            int[] array1 = convert(digit1);
	            int[] array2 = convert(digit2);
	            int[] sum = add(array1, array2);         
	
	            
	
	    System.out.print("Compute another calculation? 'yes' or 'no': ");
	        } while (digit.next().equalsIgnoreCase("yes"));

	        System.out.println("Exit.");
	        digit.close();
	    }
	        
	
	    private static int[] convert(String conversion) {
	        int length = conversion.length();
	        int[] newArray = new int[length];

	        for (int i = 0; i < length; i++) {
	            newArray[i] = Character.getNumericValue(conversion.charAt(length - 1 - i));
	        }
	        return newArray;
	    }

	    
	    private static int[] add(int[] array1, int[] array2) {
	        int maxDigit = Math.max(array1.length, array2.length);
	        int[] output = new int[maxDigit + 1];
	        int carry = 0;

	        for (int i = 0; i < maxDigit; i++) {
	            int sum = array1[i] + array2[i] + carry;
	            output[i] = sum % 10;
	            carry = sum / 10;
	        }
	            
	        if (carry > 0) {
	            output[maxDigit] = carry;
	        }   
	        return output;
	   
	    }
	    
	    private static void display(int[] output) {
	        System.out.println("Output:");
	        for (int i = output.length - 1; i >= 0; i--) {
	            System.out.print(output[i]);
	        }
	
	        System.out.println();
	        
	}
}