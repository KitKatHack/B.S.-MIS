/**
 * 
 */
/**
 * 
 */
module Lab6_7 {
}