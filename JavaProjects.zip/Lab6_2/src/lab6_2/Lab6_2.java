package lab6_2;
	//import java.util.ArrayList;
	//import java.util.Collections;
	import java.util.Random;
	import java.util.Scanner;
public class Lab6_2 {
   // public static void main(String[] args) {


		private static final int axis = 4;
	    private static final int pair = 8;

	    public static void main(String[] args) {
	        int[][] cards = initial();
	        int[][] match = new int[axis][axis];

	        shuffle(cards);

	        Scanner next = new Scanner(System.in);

	        while (!allMatch(match)) {
	            display(cards, match);

	            System.out.print("Input coordinate for card 1 (row -> column): ");
	            int row1 = next.nextInt();
	            int collumn1 = next.nextInt();

	            System.out.print("Input coordinate for card 2 (row -> column): ");
	            int row2 = next.nextInt();
	            int collumn2 = next.nextInt();

	            if (!check(row1, collumn1) || !check(row2, collumn2) ||
	            		match[row1][collumn1] == 1 || match[row2][collumn2] == 1) {
	                System.out.println("Invalid coordinate.");
	                continue;
	            }

	            match[row1][collumn1] = 1;
	            match[row2][collumn1] = 1;

	            	display(cards, match);

	            if (cards[row1][collumn1] == cards[row2][collumn2]) {
	                System.out.println("Match.");
	            } else {
	                System.out.println("Cards do not match. Cards returned to deck.");
	                match[row1][collumn1] = 0;
	                match[row2][collumn2] = 0;
	            }

	            for (int i = 0; i < 50; ++i) System.out.println();
	        }

	        System.out.println("All matching pairs found!");
	        next.close();
	    }

	    private static int[][] initial() {
	        int[][] cards = new int[axis][axis];
	        int count = 1;

	        for (int i = 0; i < pair; ++i) {
	            for (int j = 0; j < 2; ++j) {
	                int row, collumn;
	                do {
	                    row = new Random().nextInt(axis);
	                    collumn = new Random().nextInt(axis);
	                } while (cards[row][collumn] != 0);
	                cards[row][collumn] = count;
	            }
	            count++;
	        }

	        return cards;
	    }

	    private static void shuffle(int[][] cards) {
	        Random rand = new Random();
	        for (int i = 0; i < axis; i++) {
	            for (int j = 0; j < axis; j++) {
	                int randomR = rand.nextInt(axis);
	                int randomC = rand.nextInt(axis);

	                int temp = cards[i][j];
	                cards[i][j] = cards[randomR][randomC];
	                cards[randomR][randomC] = temp;
	            }
	        }
	    }

	    private static void display(int[][] cards, int[][] match) {
	        System.out.println("Deck:");

	        for (int i = 0; i < axis; i++) {
	            for (int j = 0; j < axis; j++) {
	                if (match[i][j] == 1) {
	                    System.out.print(cards[i][j] + " ");
	                } else {
	                    System.out.print("* ");
	                }
	            }
	            System.out.println();
	        }
	        System.out.println();
	    }

	    private static boolean allMatch(int[][] match) {
	        for (int i = 0; i < axis; i++) {
	            for (int j = 0; j < axis; j++) {
	                if (match[i][j] == 0) {
	                    return false;
	                }
	            }
	        }
	        return true;
	    }

	    private static boolean check(int row, int collumn) {
	        return row >= 0 && row < axis && collumn >= 0 && collumn < axis;
	    }
	}
		
		
		
		
		
		
    	
    	
    	
    	/*
		
	
		        int[][] cards = {
		                {1, 1, 2, 2},
		                {3, 3, 4, 4},
		                {5, 5, 6, 6},
		                {7, 7, 8, 8}
		        };

		        boolean[][] faceUp = new boolean[4][4];
		        initializeGame(faceUp);

		        while (!allCardsFaceUp(faceUp)) {
		            displayBoard(cards, faceUp);
		            playTurn(cards, faceUp);
		        }

		        System.out.println("All matching pairs found!");
		    }

		    private static void initializeGame(boolean[][] faceUp) {
		        Random random = new Random();
		        for (int i = 0; i < 1000; i++) {
		            int row1 = random.nextInt(4);
		            int col1 = random.nextInt(4);
		            int row2 = random.nextInt(4);
		            int col2 = random.nextInt(4);

		            // Swap two cards in the array
		            int temp = cards[row1][col1];
		            cards[row1][col1] = cards[row2][col2];
		            cards[row2][col2] = temp;
		        }
		    }

		    private static boolean allCardsFaceUp(boolean[][] faceUp) {
		        for (int i = 0; i < faceUp.length; i++) {
		            for (int j = 0; j < faceUp[i].length; j++) {
		                if (!faceUp[i][j]) {
		                    return false;
		                }
		            }
		        }
		        return true;
		    }

		    private static void displayBoard(int[][] cards, boolean[][] faceUp) {
		        for (int i = 0; i < cards.length; i++) {
		            for (int j = 0; j < cards[i].length; j++) {
		                if (faceUp[i][j]) {
		                    System.out.print(cards[i][j] + " ");
		                } else {
		                    System.out.print("* ");
		                }
		            }
		            System.out.println();
		        }
		        System.out.println();
		    }

		    private static void playTurn(int[][] cards, boolean[][] faceUp) {
		        Scanner scanner = new Scanner(System.in);

		        System.out.print("Enter the coordinates of the first card (row column): ");
		        int row1 = scanner.nextInt();
		        int col1 = scanner.nextInt();

		        System.out.print("Enter the coordinates of the second card (row column): ");
		        int row2 = scanner.nextInt();
		        int col2 = scanner.nextInt();

		        // Check if the selected cards are valid
		        if (isValidInput(row1, col1, faceUp) && isValidInput(row2, col2, faceUp)) {
		            // Check if the cards match
		            if (cards[row1][col1] == cards[row2][col2]) {
		                faceUp[row1][col1] = true;
		                faceUp[row2][col2] = true;
		                System.out.println("Match! Cards are face up.");
		            } else {
		                System.out.println("No match. Cards are face down.");
		            }
		        } else {
		            System.out.println("Invalid coordinates. Please try again.");
		        }

		        // Clear the console
		        for (int i = 0; i < 50; i++) {
		            System.out.println();
		        }
		    }

		    private static boolean isValidInput(int row, int col, boolean[][] faceUp) {
		        return row >= 0 && row < faceUp.length && col >= 0 && col < faceUp[0].length && !faceUp[row][col];
		    }
		}}
		
		
		
		
		/*
		System.out.println("Welcome to Memory Matching Game!");
		
		int [] pairs = new int [9];
		for (int i = 0; i < pairs.length; i++) {
			System.out.println("Matching Pairs: " + i);
			
		} 
		
		List<Integer> dealCount = new ArrayList<>();
		
			for (int r = 0; r < pairs.length; r++) {
				Collections.shuffle(dealCount);
			}
			
				
				
		/*		Random randomCard1 = new Random();
				int x =randomCard1.nextInt(pairs.length);
	
				Random randomCard2 = new Random();
				int y =randomCard2.nextInt(pairs.length);	
				System.out.println("Matching Dealer Coordinates: (" + x + "," + y + ")");
			
			Scanner xCoor = new Scanner(System.in);
			System.out.println("Please input x coordinate ranging from 0-4:");
				xCoor.nextInt();
				
				if(xCoor == x) {
					pairs.remove(r);
					
				}
		
				Scanner yCoor = new Scanner(System.in);
				System.out.println("Please input y coordinate ranging from 0-4:");
					yCoor.nextInt();*/
					
		

	
					
	/*	Scanner card = new Scanner(System.in);
		System.out.println("Please input coordinates in (x,y) format ranging from 0-4:");
			card.nextInt();*/

			
			
			
			
		/*	int [] faceValue = new int [9];
			for (int i = 0; i < faceValue.length; i++) {
				//if statement//
			
			}
			
			
		/*int [] deck2 = new int [9];
		for (int i = 0; i < deck2.length; i++) {
			System.out.println("Card: " + i);
		}*/ // chose to do 1 array for both face value and collection// 
		
		
		/*List <Integer> dealDeck1 = new ArrayList<>();
		for (int r = 0; r <= 8; r++) {	
			dealDeck1.add(r);
		}
		
		Collections.shuffle(cardDeck);*/

		
		
		

		/*Scanner card1 = new Scanner(System.in);
		System.out.println("Please input coordinates in (x,y) format ranging from 0-4:");
			card1.nextInt();*/
		
			
			
	/*	
		List <Integer> dealDeck2 = new ArrayList<>();
		for (int r = 0; r <= 4; r++) {	
			dealDeck2.add(r);
			dealDeck2.add(r);

		}
		Random randomCard2 = new Random();
		/*Collections.shuffle(dealDeck2);*/
		/*System.out.println("Matching Pairs: " + dealDeck2);*/
		
		/*Scanner card2 = new Scanner(System.in);
		System.out.println("Please input coordinates in (x,y) format ranging from 0-4:");
			card2.nextInt();*/
		
		
		/*System.out.println("Dealer Card: " + dealDeck);*/ //Testing dealDeck: test passed//

			/*Random shuffleCards = new Random();
			
			
			int shuffle = shuffleCards.nextInt(r);
			numbers.add(r);
			/*dealDeck[shuffle] = dealDeck[r];
			dealDeck[r] = shuffle;
			System.out.println(shuffle);*/
			

			
			/*List<Integer> shuffleList = Arrays.asList(shuffleList);
			shuffleList.toArray();
			Collections.shuffle(shuffleList);
			System.out.println(shuffleList);*/
			
			
			/*Random shuffleCards = new Random();
			int shuffle = shuffleCards.nextInt(r);
			System.out.println("Dealer Card: " + shuffle);*/
			
			
			/*int [] shuffledDeck = new int[17];
			for(int d = 1; d < shuffledDeck.length;d++) {
			}
			
			if(int )*/
			
		
		
		/*deck[0] = "*";
		deck[1] = "*";
		deck[2] = "*";
		deck[3] = "*";
		deck[4] = "*";
		deck[5] = "*";*/

		/*
		for (int i =0; i < deck; i++) {
			System.out.println("Here is deck of cards")
		}*/
		
		/*
		Scanner cardGame = new Scanner(System.in);
		System.out.println("Please choose 2 cards (1-16):");
			cardGame.nextInt();
		*/
		
			
			



/* Deck of cards (contain identical pairs) 
 * For example, given six cards in the deck, 2 might be labeled 1, 2 labeled 2, and 2 labeled 3. 
 * The cards are shuffled and placed face down on the table. 
 * A player then selects two cards that are face down, turns them face up, and if the cards 
 * match, they are left face up. 
 * If the two cards do not match, they are returned to their original face down position. 
 * The game continues until all cards are face up.


Write a program that plays the memory matching game. 
Use 16 cards that are laid out in a 4 × 4 square 
are labeled with pairs of numbers from 1 to 8. 
 Program should allow the player to specify cards they would like to select through coordinate 
 system. All of the face down cards are indicated by an asterisk (*). 

Use a 2D array for the arrangement of cards and another 2D array that indicates if a card is face up or face down. Write a function that “shuffles” the cards in the array by repeatedly selecting two cards at random and swapping them.

See example below - the pairs of 8 that are face up are at coordinates (1,1) and (2,3). To hide the cards that have been temporarily placed face up, output a large number of newlines to force the old board off the screen.
*/