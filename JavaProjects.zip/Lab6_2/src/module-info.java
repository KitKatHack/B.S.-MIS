/**
 * 
 */
/**
 * 
 */
module Lab6_2 {
}