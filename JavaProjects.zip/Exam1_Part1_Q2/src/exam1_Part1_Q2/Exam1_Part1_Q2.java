package exam1_Part1_Q2;
	import java.util.Scanner;
	
public class Exam1_Part1_Q2 {
	public static void main (String [] args) {
	 Scanner Keyboard = new Scanner (System.in);

	 
	 System.out.println ("Please insert time it takes to run in seconds");
	 	double seconds = Keyboard.nextDouble();
	
	 	
	 	double hour = seconds/3600;
	 	double min = (seconds % 3600)/60;
	 	double sec = (seconds % 3600) % 60;	
	 	

	 System.out.println ("You ran " + hour + " in hours " + min + " in minutes " + sec + " in seconds.");	
	
	
	 
	}
}
