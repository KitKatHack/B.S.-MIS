package lab6_4;
public class Lab6_4 {
	public static void main (String[]args) {
		
		char [] a = new char[10];
		
		a[0] = 'a';
		a[1] = 'b';
		a[2] = 'a';
		a[3] = 'd';
		
		int size = 4;
		
		size = deleteRepeats(a, size);
		
		
		System.out.println("Starting array:");
			for(int i = 0; i< size; i++) {
				System.out.println("a [" + i + "] = " + a[i]);

			}
		System.out.println("New Array:" + size);
	}
	
	
	public static int deleteRepeats(char[] array, int size) {
		for (int i =0; i < size; i++) {
			char e = array [i];
			for(int b = i + 1; b < size; b++) {
				if (array[b] == e) {
					for(int c = b; c < size - 1; c++) {
						array[c] = array [c+1];
					}
					size --;
					b--;
				}
			}
		}
	
		return size;
		
	}
}
