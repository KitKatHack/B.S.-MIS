package practice1_Exam1Pt2;
import java.util.Scanner;

public class Practice1_Exam1Pt2 {
	public static void main (String [] args) {
		Scanner Keyboard = new Scanner(System.in);
	
	System.out.println ("Please enter your pre-tax grocery bill:");
	
	
	double preTaxBill = Keyboard.nextDouble();
	
	
		double taxRate = .07;
		double totalBill = preTaxBill + (preTaxBill * taxRate);
		
		System.out.printf("Your total grocery bill is $" + "%8.2f", totalBill);
		System.out.println();
		
		System.out.printf("You paid with a $100 bill so I owe you $" + (100 - totalBill));

	
	
	
	
	
	}
}
