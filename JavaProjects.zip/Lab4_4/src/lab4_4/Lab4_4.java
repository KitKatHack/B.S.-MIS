package lab4_4;
	import java.util.Date;
public class Lab4_4 {
	public static void main (String [] args) {
		
		
		String username = ("Guest748");
		String txt = ("This line of text is to challenge prompt into printing line of text.");
		Date date = new Date();
		
		BlogEntry blogEntry = new BlogEntry(username, txt, date);
		
		System.out.println(username);
		System.out.println(date);

		String summary = blogEntry.summary();
		System.out.println("Summary: " + summary);
		
	}
	
}
