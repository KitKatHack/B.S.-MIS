package lab4_4;
	import java.util.Date;
public class BlogEntry {
	private String username;
	private String txt;
	private Date date;

	
	public BlogEntry(String username, String txt, Date date) {
		this.username = username;
		this.txt = txt;
		this.date = date;
	}
	
	public void entry () {
		System.out.println("Username: " + username);
		System.out.println("Text: " + txt);
		System.out.println("Date: " + date);
	}
	
	public String summary() {
	String [] words = txt.split(" ");
	int numWords = Math.min(10, words.length);
	StringBuilder summary = new StringBuilder();
	
	for (int i = 0; i < numWords; i++) {
		summary.append(words[i]);
		summary.append(" ");
	}
	
	return summary.toString();
	}
}
