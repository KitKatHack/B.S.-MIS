package exam2_Pt2_Q1;

public class Bicycle {

	private String bicycleSize;
	private int smallPrice = 80;
	private int mediumPrice = 100;
	private int largePrice = 115;
	private double bicycleCost;
	private int bell;
	private int basket;
	private int whistle;
	
	public Bicycle(String bicycleSize, int bell, int basket, int whistle) {
		this.bicycleSize = bicycleSize;
		this.bell = bell;
		this.basket = basket;
		this.whistle = whistle;
	}
	public String getSize() {
		return bicycleSize;
	}
	
	public void setSize(String bicycleSize) {
		bicycleSize = this.bicycleSize;
	}
	public int bell() {
		return bell;
	}
	public void setBell(int bell) {
		bell = this.bell;
	}
	public int basket() {
		return basket;
	}
	public void setBasket(int basket) {
		basket = this.basket;
	}	
	public int whistle() {
		return whistle;
	}
	public void setWhistle(int whistle) {
		whistle = this.whistle;
	}	
	
	public double calcCost() {
		if(bicycleSize.equalsIgnoreCase("small")) {
			bicycleCost = smallPrice + (4*bell) + (4*basket) + (4*whistle);
			return bicycleCost;
		}
		else if(bicycleSize.equalsIgnoreCase("medium")) {
			bicycleCost = mediumPrice + (4*bell) + (4*basket) + (4*whistle);
			return bicycleCost;
		}
		else if(bicycleSize.equalsIgnoreCase("large")) {
			bicycleCost = largePrice + (4*bell) + (4*basket) + (4*whistle);
			return bicycleCost;
	}
		return bicycleCost;
	}
		public String getDescription() {
			return "Bicycle Size: " + bicycleSize + "\nBells: " + bell + "\nBaskets: " + basket + "\nWhistles: " + whistle + "\nCost: " + calcCost();
		
	}
	/*	public double calcPrice() {
			return 0;
		}*/



		private String model;
		private double price;

		public Bicycle(String model, double price) {
			this.model = model;
			this.price = price;
		}

		public double getPrice() {
			return price;
		}}
