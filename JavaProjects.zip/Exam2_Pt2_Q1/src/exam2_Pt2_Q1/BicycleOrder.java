package exam2_Pt2_Q1;

public class BicycleOrder {
	   private int numBicycles;
	    private Bicycle bicycle1;
	    private Bicycle bicycle2;
	    private Bicycle bicycle3;

	    public BicycleOrder() {
	        this.numBicycles = 0;
	    }

	    public void setNumBicycles(int numBicycles) {
	        if (numBicycles >= 1 && numBicycles <= 3) {
	            this.numBicycles = numBicycles;
	        } else {
	            System.out.println("Invalid number of bicycles. Set to a value between 1 and 3.");
	        }
	    }

	    public void setBicycle1(Bicycle bicycle1) {
	        this.bicycle1 = bicycle1;
	    }

	    public void setBicycle2(Bicycle bicycle2) {
	        if (numBicycles >= 2) {
	            this.bicycle2 = bicycle2;
	        } else {
	            System.out.println("Error: Cannot set second bicycle when the order has less than 2 bicycles.");
	        }
	    }

	    public void setBicycle3(Bicycle bicycle3) {
	        if (numBicycles == 3) {
	            this.bicycle3 = bicycle3;
	        } else {
	            System.out.println("Error: Cannot set third bicycle when the order does not have 3 bicycles.");
	        }
	    }

	    public double calcTotal() {
	        double totalCost = 0.0;

	        if (bicycle1 != null) {
	            totalCost += bicycle1.getPrice();
	        }

	        if (bicycle2 != null) {
	            totalCost += bicycle2.getPrice();
	        }

	        if (bicycle3 != null) {
	            totalCost += bicycle3.getPrice();
	        }

	        return totalCost;
	    }

		
		

	    private int numBicycles;
	    private Bicycle bicycle1;
	    private Bicycle bicycle2;
	    private Bicycle bicycle3;

	    public BicycleOrder() {
	        this.numBicycles = 0;
	    }

	    public void setNumBicycles(int numBicycles) {
	        if (numBicycles >= 1 && numBicycles <= 3) {
	            this.numBicycles = numBicycles;
	        } else {
	            System.out.println("Invalid number of bicycles. Set to a value between 1 and 3.");
	        }
	    }

	    public void setBicycle1(Bicycle bicycle1) {
	        this.bicycle1 = bicycle1;
	    }

	    public void setBicycle2(Bicycle bicycle2) {
	        if (numBicycles >= 2) {
	            this.bicycle2 = bicycle2;
	        } else {
	            System.out.println("Error: Cannot set second bicycle when the order has less than 2 bicycles.");
	        }
	    }

	    public void setBicycle3(Bicycle bicycle3) {
	        if (numBicycles == 3) {
	            this.bicycle3 = bicycle3;
	        } else {
	            System.out.println("Error: Cannot set third bicycle when the order does not have 3 bicycles.");
	        }
	    }

	    public double calcTotal() {
	        double totalCost = 0.0;

	        if (bicycle1 != null) {
	            totalCost += bicycle1.getPrice();
	        }

	        if (bicycle2 != null) {
	            totalCost += bicycle2.getPrice();
	        }

	        if (bicycle3 != null) {
	            totalCost += bicycle3.getPrice();
	        }

	        return totalCost;
	    }

	    public static void main(String[] args) {
	        // Sample code illustrating the methods
	        BicycleOrder order = new BicycleOrder();

	        Bicycle bike1 = new Bicycle("Model1", 100.0);
	        order.setBicycle1(bike1);

	        Bicycle bike2 = new Bicycle("Model2", 150.0);
	        order.setBicycle2(bike2);

	        order.setNumBicycles(2);

	        System.out.println("Total cost of the order: $" + order.calcTotal());
	    }
	}
