package exam2_Pt2_Q1;
public class Exam2_Pt2_Q1 {
	public void main (String [] args) {
		
		Bicycle smallBicycle = new Bicycle("small", 1, 2, 2);
		Bicycle mediumBicycle = new Bicycle("medium", 3, 5, 4);
		Bicycle largeBicycle = new Bicycle("large", 8, 4, 7);

		System.out.println(smallBicycle.getDescription());
		System.out.println(mediumBicycle.getDescription());
		System.out.println(largeBicycle.getDescription());


		/*
		System.out.println("Bicycle Order:\n");
		  
		Bicycle bicycle1 = new Bicycle("Large", 1, 1, 0);
	        Bicycle bicycle2 = new Bicycle("Medium", 2, 0, 2);
	        
	        BicycleOrder order = new BicycleOrder();
	        order.setTotalBicycles(2);
	        order.setBicycle1(bicycle1);
	        order.setBicycle2(bicycle2);

	        double total = order.calcTotal();
	        System.out.println("Total cost of the bicycles: $" + total);*/
	
		
		        BicycleOrder order = new BicycleOrder();

		        Bicycle bicycle1 = new Bicycle("large", 100.0);
		        order.setBicycle1(bicycle1);

		        Bicycle bicycle2 = new Bicycle("medium", 150.0);
		        order.setBicycle2(bicycle2);

		        order.setNumBicycles(2);

		        System.out.println("Total cost of the order: $" + order.calcTotal());		 
		    
		
		
	}
	
}
