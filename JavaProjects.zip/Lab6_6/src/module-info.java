/**
 * 
 */
/**
 * 
 */
module Lab6_6 {
}