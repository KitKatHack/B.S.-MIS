package lab6_6;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
public class Lab6_6 {
	public static void main (String[]args) {

		 Scanner key = new Scanner(System.in);

	        int[] array = new int[50];
	        int count = 0;

	        System.out.println("Please input up to 50 numbers. Type 'fin' when finished:");

	        while (count < 50) {
	            String input = key.next();
	            if (input.equalsIgnoreCase("fin")) {
	                break;
	            }

	            try {
	                array[count] = Integer.parseInt(input);
	                count++;
	            } catch (NumberFormatException e) {
	                System.out.println("Error.");
	            }
	        }

	        array = Arrays.copyOfRange(array, 0, count);

	        Map<Integer, Integer> counts = new HashMap<>();

	        for (int x : array) {
	            counts.put(x, counts.getOrDefault(x, 0) + 1);
	        }

	        int[] numbers = counts.keySet().stream().sorted((a, b) -> Integer.compare(b, a)).mapToInt(Integer::intValue).toArray();

	        System.out.println("  N    Count");
	        for (int number : numbers) {
	            System.out.printf("%4d   %d\n", number, counts.get(number));
	        }

	        key.close();
	    }
	}
