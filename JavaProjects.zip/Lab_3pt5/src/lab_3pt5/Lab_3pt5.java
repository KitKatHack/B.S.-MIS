package lab_3pt5;
	import java.util.Scanner;
public class Lab_3pt5 {
	public static void main (String [] args) {
		Scanner Keyboard = new Scanner (System.in);


		double interestRate = .015;
		double loan = 1000;
		double monthPayment = 50;
	
		System.out.println ("You paid $1000 with 0 down payment.\n");

		System.out.println ("Your interest rate is 18% per year (1.5% per month).\n");

		System.out.println ("You set your monthly payments to $" + monthPayment + ", $15 will go towards the interest, and remaining $35 is deducted from debt owed.\n");

		double remainDebt = loan;
		int months = 0;
		double totalIntPaid = 0;

		
	
		while (remainDebt > 0) {
			double monthInterest = remainDebt*interestRate;
			double monthPrinciple = monthPayment - interestRate;
			totalIntPaid += monthInterest;
			remainDebt -= monthPrinciple;
			months++;
	
				System.out.printf ("You paid $ " + monthPayment + " and now owe $" + "%-6.2f", remainDebt);
				
				System.out.printf ("  Total interest paid is $ " + "%-6.2f", totalIntPaid);
				System.out.println (" It took " + months + " months to pay loan.");

	
		}	
	}
}