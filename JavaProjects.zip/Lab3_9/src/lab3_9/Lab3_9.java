package lab3_9;
import java.util.Scanner;
import java.text.DecimalFormat;
public class Lab3_9 {
	public static void main (String[] args) {
		Scanner keyboard = new Scanner(System.in);

		
		
		
		
		System.out.println ("How many exercises to input?");
		int exerciseInput = keyboard.nextInt();
		
	
		
		int score = 0;
		int points = 0;
		
		if (exerciseInput >= 1) {
			 score = 10;
			System.out.println ("Score for exercise 1 is " + score);
			
			 points = 10;
			System.out.println ("Points for exercise 1 is " + points);
		}
		  if (exerciseInput >= 1) {
			score = 7;
		System.out.println ("Score for exercise 2 is " + score);
	
			points = 12;
		System.out.println ("Points for exercise 2 is " + points);
		 
		 } if (exerciseInput >= 1){
			score = 5;
		System.out.println ("Score for exercise 3 is " + score);
	
			points = 8;
		System.out.println ("Points for exercise 3 is " + points);
		 }
		 
			double totalScore = 10 + 7 + 5;
			double totalPoints = 10 + 12 + 8;
			double totalPercent = (totalScore/totalPoints)*100;
			
			 DecimalFormat decimalFormat = new DecimalFormat("0.00");
			 String percent = decimalFormat.format(totalPercent);
			System.out.println ("Your total is " + totalScore + " out of " + totalPoints);
			System.out.printf ("Your overall total is " + percent);
		
			
	}
}
		/* THOUGHT PROCESS
		for (int i = 1; i <= exerciseInput; i++) {
			int score = 10;
			System.out.println ("Score for exercise 1 is " + score);
			
			int points = 10;
			System.out.println ("Points for exercise 1 is " + points);
		}
		
		for (int i = 1; i <= exerciseInput; i++) {
			int score = 7;
			System.out.println ("Score for exercise 2 is " + score);
		
			int points = 12;
			System.out.println ("Points for exercise 2 is " + points);
	}
		
		for (int i = 1; i <= exerciseInput; i++) {
			int score = 5;
			System.out.println ("Score for exercise 3 is " + score);
		
			int points = 8;
			System.out.println ("Points for exercise 3 is " + points);
			
		*/
			
			/*
			
			totalScore += score;
			totalPoints += points;
		}
		
		double percent = totalScore/totalPoints;
		System.out.println ("Your total is " + totalScore + " out of " + totalPoints);
		System.out.printf ("Your overal total is " + "%2.2f", percent);
			
			
	*/
		 
/*	
for (int i = 1, i <= exerciseInput, i++) {
System.out.println ("Score for exercise 1 is " + i);
int score = keyboard.nextInt();

System.out.println ("Points for exercise 1 is " + i);
int point = keyboard.nextInt();*/